# Test for Python Packaging

This repository is to test the concepts exposed in the **Python Packaging User Guide**
(more specifically, the tutorial presented 
[here](https://packaging.python.org/en/latest/tutorials/packaging-projects/), 
last accessed on Friday 12th March 2024).