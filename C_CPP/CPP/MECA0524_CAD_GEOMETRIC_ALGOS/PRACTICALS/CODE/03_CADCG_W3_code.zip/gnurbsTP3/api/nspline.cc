// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nspline.h"

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "linear_algebra.h"

void nspline::P(double u_, npoint& ret) const
{
  // You have to implement this.

  // Find which spline : u* until 0<u*<1
  double u_local;
  int subcurve_i = -1;

  do {
    subcurve_i++;
    u_local = (u_ - u(subcurve_i))/(u(subcurve_i+1)-u(subcurve_i));
  } while (u_local < 0. || u_local > 1.);

  double der_ToLocal = (u(subcurve_i+1)-u(subcurve_i));

  npoint ai0 = CP(subcurve_i);
  npoint ai1 = (type!=Cardinal) ? der[subcurve_i]*der_ToLocal : der[subcurve_i];
  npoint ai2 = (type!=Cardinal) ? 3.*(CP(subcurve_i+1)-CP(subcurve_i)) - der[subcurve_i+1]*der_ToLocal - 2.*der[subcurve_i]*der_ToLocal : 3.*(CP(subcurve_i+1)-CP(subcurve_i)) - der[subcurve_i+1] - 2.*der[subcurve_i];
  npoint ai3 = (type!=Cardinal) ? 2.*(CP(subcurve_i)-CP(subcurve_i+1)) + der[subcurve_i]*der_ToLocal + der[subcurve_i+1]*der_ToLocal : 2.*(CP(subcurve_i)-CP(subcurve_i+1)) + der[subcurve_i] + der[subcurve_i+1];

  ret = ai0 + (u_local*(ai1 + (u_local*(ai2 + u_local*ai3))));

}

void nspline::compute_FD(void)
{
  type=FiniteDifferences;

  // see nspline.h for vector of derivative : protected std::vector<npoint> der;

  der[0] = (CP(1) - CP(0)) / (u(1) - u(0));
  der[nCP-1] = (CP(nCP-1) - CP(nCP-2)) / (u(nCP-1) - u(nCP-2));

  for(int index = 1; index < nCP-1; ++index){
    der[index] = .5*(CP(index+1) - CP(index)) / (u(index+1) - u(index)) + .5*(CP(index) - CP(index-1)) / (u(index) - u(index-1));
  }

}

void nspline::compute_cardinal(double c)
{
  card=c;
  type=Cardinal;

  der[0] = (1-c)*(val[1]-val[0]);
  der[nCP-1] = (1-c)*(val[nCP-1]-val[nCP-2]);

  for(int index=1; index<nCP-1 ; ++index){
    der[index] = (1-c)*.5*(val[index+1]-val[index-1]);
  }

}

void nspline::compute_natural(void)
{
  type=Natural;

  Square_Matrix M(nCP);

  M(0,0) = 2.*(u(1)-u(0));
  M(0,1) = (u(1)-u(0));

  for(int i=1; i<nCP-1; ++i){
    M(i,i-1) = u(i+1)-u(i);
    M(i,i+1) = u(i)-u(i-1);
    M(i,i) =  2.*( u(i+1) - u(i-1) );
  }

  M(nCP-1,nCP-2) = (u(nCP-1)-u(nCP-2));
  M(nCP-1,nCP-1) = 2.*(u(nCP-1)-u(nCP-2));

//  M.Display();

  LU_Matrix M_ = LU_Matrix(M);

  for(int coord = 0; coord<4; ++coord){

    Vector P_der(nCP);
    Vector P_delta(nCP);
//    std::vector<double> P_delta(nCP);

    for(int i=0; i<nCP-1; ++i){

        P_delta[i] = (i==0) ? 3.*(val[i+1][coord]-val[i][coord]) : 3.*( ((u(i+1)-u(i))/(u(i)-u(i-1)))*(val[i][coord]-val[i-1][coord]) + ((u(i)-u(i-1))/(u(i+1)-u(i)))*(val[i+1][coord]-val[i][coord]) );

    }
        P_delta[nCP-1] = 3.*(val[nCP-1][coord]-val[nCP-2][coord]);

    M_.Solve_Linear_System(P_delta,P_der);

//    tridiagsolve(P_delta);

    for(int i=0; i<=nCP-1;++i) der[i][coord] = P_der[i];
//    for(int i=0; i<=nCP-1;++i) der[i][coord] = P_delta[i];

  }

//    for(int i=0; i<=nCP-1; ++i){
//        printf("[ %f, %f, %f, %f ]\n",der[i][0],der[i][1],der[i][2],der[i][3]);
//    }
}

void nspline::tridiagsolve(std::vector<double> &rhs) // fast linear solver
{
  int n=nb_CP();
  std::vector<double> c(n);
  double h0=u(1)-u(0);
  c[0]=h0;
  double b0=2*h0;
  c[0] /= b0;
  rhs[0] /= b0;
  for (int i = 1; i < n-1; i++)
  {
    double hi=u(i+1)-u(i);
    double him1=u(i)-u(i-1);
    double bi=2*hi+2*him1;
    double ai=hi;
    c[i] = him1;
    double id=1 / (bi - c[i-1] * ai);
    c[i]*=id;
    rhs[i] = (rhs[i] - rhs[i-1] * ai) * id;
  }
  int i=n-1;
  double him1=u(i)-u(i-1);
  double bi=2*him1;
  double ai=him1;
  double id=1 / (bi - c[i-1] * ai);
  rhs[i] = (rhs[i] - rhs[i-1] * ai) * id;

  for (int i = n - 2; i >= 0; i--)
    rhs[i] = rhs[i] - c[i] * rhs[i + 1];
}


void nspline::tridiagsolve_circulant(LU_Matrix &LU,std::vector<double> &rhs) // somewhat slow due to general LU factorization (done once).
{
  int n=nb_CP();

  Vector Rhs(n-1);
  for (int i = 0; i < n-1; i++) Rhs(i)=rhs[i];
  Vector Sol(n-1);
  LU.Solve_Linear_System(Rhs,Sol);
  for (int i = 0; i < n-1; i++) rhs[i]=Sol(i);
}

void nspline::update()
{
  switch (type)
  {
    case FiniteDifferences :
      compute_FD();
      break;
    case Cardinal :
      compute_cardinal(card);
      break;
    case Natural :
      compute_natural();
      break;
  }
}
