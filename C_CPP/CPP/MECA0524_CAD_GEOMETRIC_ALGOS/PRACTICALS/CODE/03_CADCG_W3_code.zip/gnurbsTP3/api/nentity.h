// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NENTITY_H
#define __NENTITY_H

#include "nutil.h"


/// Abstract entity.
class nentity : public ndrawable
{
public:
  /// \brief Discretizes the entity.
  virtual void Discretize(std::vector<npoint3> &pts, double du=0., double ds=0., double eps=0., double epsr=0.) const {};

  /// \brief Returns the total number of control points.
  /// \return Number of control points.
  virtual int nb_CP(void) const {return 0;}

  /// \brief Returns a control point (const-version) (default impl).
  /// \param[in] which wanted control point number.
  /// \return Control point.
  virtual npoint CP(int which) const {return npoint();}

  /// \brief Sets a control point.
  /// \param[in] which control point number to set.
  /// \param[in] pt new control point.
  virtual void set_CP(int which,const npoint& pt) {} ;
  virtual std::string info() {return std::string("nentity");} ;
  virtual nentity* clone() const =0 ;
};

#endif //__NENTITY_H
