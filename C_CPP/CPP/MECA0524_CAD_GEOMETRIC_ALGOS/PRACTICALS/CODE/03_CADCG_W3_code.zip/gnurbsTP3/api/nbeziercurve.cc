// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nbeziercurve.h"

#include <cmath>
#include <iostream>

void nbeziercurve::P(double u_, npoint& ret) const
{
// you have to implement this
}

void nbeziercurve::degree_elevation()
{
// you have to implement this
}

void nbeziercurve::cut(double u_, npoint& ret,nbeziercurve &left,nbeziercurve &right) const
{
// you have to implement this
}


void nbeziercurve::translate(npoint vec)
{
  for (int i=0;i<nCP;++i) CP(i)=CP(i)+vec;
}
