// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <fstream>
#include "nlagrange.h"
#include "nspline.h"
#include "nbeziercurve.h"
#include "ndisplay.h"
#include "nutil.h"
#include "gnurbscallbacks.h"

// Initialization function prototype
// the complete implementation can be found at the end of the file
// DX and DY are the offsets with respect to the origin
void init_bezier(nbeziercurve &curve,double DX,double DY);

// main function

int main(void)
{
  ndisplay display;                // Display window
  int nCP=7;                          // Number of control points
  nbeziercurve curve(nCP);            // Bezier curve with nCP control points
  init_bezier(curve,0.0,0.);          // Curve initialization

  nbeziercurve curve_elev(nCP);       // New Bezier curve with nCP control points
  init_bezier(curve_elev,0.,-1.5);    // curve_elev is initialized with the same control points as curve3
  curve_elev.degree_elevation();      // Degree elevation for curve_elev

  gnurbscallbacks CB;
  properties props;
  props.pointsize = 5.0f;
  CB.add_entity(&curve,props);
  CB.add_entity(&curve_elev,props);

  display.setcallbacks(&CB);
  CB.draw();
  display.init_data(CB.datas);        // Transfer of the data to display
  display.display();        	     // Display and interaction loop
  return 0;
}

void init_bezier(nbeziercurve &curve,double DX,double DY)
{
  for (int i=0;i< curve.nb_CP();i++)
  {
    double angle=i*n_pi/(curve.nb_CP()-1);
    npoint val;
    val[0]=cos(angle)+DX;
    val[1]=sin(angle)+DY;
    val[2]=0;
    val[3]=1;
    curve.CP(i)=val;
  }
}
