// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __VTKDISPLAY_H
#define __VTKDISPLAY_H

#include <vector>

#include <vtkSmartPointer.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include "nutil.h"

/// Display class.
class vtkdisplay : public ndisplay_base
{
protected :
  vtkSmartPointer<vtkRenderer> renderer;
  vtkSmartPointer<vtkRenderWindow> renderWindow;
  vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor;
  vtkSmartPointer<vtkInteractorStyleTrackballCamera> interactorObserver;

public:
  /// \brief Constructor.
  vtkdisplay(color c=color(25, 51, 102,255),const char *nom=NULL);

  /// \brief Destructor.
  virtual ~vtkdisplay() {}

  /// \brief Adds all data for display.
  /// \param[in] data data to display.
  virtual void init_data(const data_container &data);
  
  /// \brief Adds all data for display.
  /// \param[in] data vector of data to display.
  virtual void init_data(const std::vector<data_container> &data);   // all
 
  
  virtual void init_data() {};
  virtual data_container* get_data() { return 0x0;}

  /// \brief Display loop.
  virtual void display();
   // self created
  virtual void test(void);
  virtual void resetCamera();
  virtual void kbCallback(int);
  virtual void mousewheelforwardCall(int x,int y);
  virtual void mousewheelbackwardCall(int x,int y);
private :
  
  /// \brief Adds only vertices data for display.
  /// \param[in] data data to display.
  virtual void init_data_vertices(const data_container & data);

  /// \brief Adds only lines data for display.
  /// \param[in] data data to display.
  virtual void init_data_lines(const data_container & data);

  /// \brief Adds only triangles data for display.
  /// \param[in] data data to display.
  virtual void init_data_triangles(const data_container & data);

  /// \brief Adds only quads data for display.
  /// \param[in] data data to display.
  virtual void init_data_quads(const data_container & data);

  /// \brief Adds only text data for display.
  /// \param[in] data data to display.
  virtual void init_data_texts(const data_container & data);
  
  std::vector<vtkSmartPointer<vtkActor> > list_numero[3];
  bool numero[3];
  std::vector<vtkSmartPointer<vtkActor> > list_triangle;
  bool triangle;
  std::vector<vtkSmartPointer<vtkActor> > list_vertice;
  bool vertice;
  std::vector<vtkSmartPointer<vtkActor> > list_line;
  bool line;
  std::vector<vtkSmartPointer<vtkActor> > list_quad;
  bool quad;
  void saveCameraDefault();
  double cameraDefPosition [3];
  double cameraDefFocalPoint [3];
  double cameraDefViewUp [3];
  double scaleactif;
};


#endif// __VTKDISPLAY_H
