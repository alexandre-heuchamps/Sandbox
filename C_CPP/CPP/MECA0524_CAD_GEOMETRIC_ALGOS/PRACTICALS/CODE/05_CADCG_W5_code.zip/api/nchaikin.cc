//
// C++ Implementation: Chaikin's scheme
//
// Description: George Chaikin, An algorithm for high speed curve generation, Computer graphics and Image
// Processing 3 (1974) , 346-349
//
//
// Authors: Eric Bechet <eric.bechet@ulg.ac.be> (C) 201
//          Christophe Leblanc.
//
//
// Copyright: See COPYING file that comes with this distribution
//
//

#include "nchaikin.h"

void nchaikin::refine(int nb_iter)
{
  // Insert your code here...
}

void nchaikin::Display(data_container &data) const
{
  properties prop_pt;
  prop_pt.pointsize = 5;
  data.setproppoints(prop_pt);
  const color c(0,255,0);
  data.setcolorpoints(c);

  for(int i = 0; i < nCP-1; ++i) {
    npoint3 temp1, temp2;

    for(int j = 0; j < 3; ++j) {
      temp1[j] = val[i][j] / val[i][3];     // Homogeneous coordinates to 3D.
      temp2[j] = val[i+1][j] / val[i+1][3]; // Homogeneous coordinates to 3D.
    }

    // Add points to data.
    data.add_point(temp1);
    data.add_point(temp2);

    // Add line to data.
    line ltemp(temp1, temp2);
    data.add_line(ltemp);
  }
}
