// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nbeziercurve.h"

#include <cmath>

void nbeziercurve::P(double u_, npoint& ret) const
{
  DeCasteljau(u_,ret);
  /*  for (int k =0 ; k<4;++k)   ret[k]=0;
    for (int i = 0; i <= degree(); ++i)
    {
      double weight=Basis(i,u_);
      ret += val[i] * weight;
    }*/
}

void nbeziercurve::dPdu(double u_,npoint& ret) const
{
  std::vector<npoint> vec(2);
  DeCasteljau(u_,1,vec);
  ret=(vec[1]-vec[0])*degree();
}

void nbeziercurve::d2Pdu2(double u_,npoint& ret) const
{
  std::vector<npoint> vec(3);
  DeCasteljau(u_,2,vec);
  int d=degree();
  ret=(vec[2]+vec[0]-2*vec[1])*d*(d-1);
}

void nbeziercurve::DeCasteljau(double u_, npoint & ret) const
{
  double u1_ = 1.-u_;
  if (nCP>2)
  {
    std::vector<npoint> vec(nCP-1);
    for (int i=0;i<nCP-1;++i)
    {
      vec[i]=val[i]*u1_+val[i+1]*u_;
    }
    for (int i=nCP-2;i>1;--i)
    {
      for (int j=0;j<i;++j)
      vec[j]=vec[j]*u1_+vec[j+1]*u_;
    }
    ret=vec[0]*u1_+vec[1]*u_;
    return;
  }
  else if (nCP==2)
  {
    ret=val[0]*u1_+val[1]*u_;
  }
  else
    ret=val[0];
}

void nbeziercurve::DeCasteljau(double u_, int stop,std::vector<npoint>& ret) const
{  
  if (stop>=nCP-1)
  {
    for (int i=0;i<nCP;++i)
    {
      ret[i]=val[i];
    }
    return;
  }
  double u1_=1.-u_;
  if (stop==nCP-2)
  {
    for (int i=0;i<nCP-1;++i)
    {
      ret[i]=val[i]*u1_+val[i+1]*u_;
    }
    return;
  }
  std::vector<npoint> vec(nCP-1);
  for (int i=0;i<nCP-1;++i)
  {
    vec[i]=val[i]*u1_+val[i+1]*u_;
  }
  for (int i=nCP-2;i>stop+1;--i)
  {
    for (int j=0;j<i;++j)
    vec[j]=vec[j]*u1_+vec[j+1]*u_;
  }
  for (int i=0;i<stop+1;++i)
  {
    ret[i]=vec[i]*u1_+vec[i+1]*u_;
  }
}


void nbeziercurve::DeCasteljau(double u_, npoint & ret,nbeziercurve &left,nbeziercurve &right) const
{
  left.add_CP(CP(0));
  right.add_CP(CP(nb_CP()-1));
  if (nb_CP() ==1)
    ret= CP(0);
  else
  {
    nbeziercurve tmp(nb_CP()-1);
    for (int i=0;i<tmp.nb_CP();++i)
      tmp.set_CP(i,CP(i) * (1-u_) +CP(i+1) *u_);
    tmp.DeCasteljau(u_,ret,left,right);
  }
}

void nbeziercurve::translate(npoint vec)
{
  for (int i=0;i<nCP;++i) CP(i)=CP(i)+vec;
}
