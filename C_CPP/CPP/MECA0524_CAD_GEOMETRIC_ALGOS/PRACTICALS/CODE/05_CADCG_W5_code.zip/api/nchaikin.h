//
// C++ Implementation: Chaikin's scheme
//
// Description: George Chaikin, An algorithm for high speed curve generation, Computer graphics and Image
// Processing 3 (1974) , 346-349
//
//
// Authors: Eric Bechet <eric.bechet@ulg.ac.be> (C) 201
//          Christophe Leblanc.
//
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef __NCHAIKIN_H
#define __NCHAIKIN_H

#include "ncurve.h"
#include <vector>

class nchaikin
{
protected:
  std::vector<npoint> val; // vertices
  int nCP; // number of vertices
public:
  nchaikin(): val(1), nCP(1) { val[0] = npoint(); }
  nchaikin(int nCP_): val(nCP_), nCP(nCP_) {}
  int nb_CP(void) const
  {
    return nCP;
  }
  const npoint& CP(int which) const
  {
    return val[which];
  }
  npoint& CP(int which)
  {
    return val[which];
  }
  void set_CP(int which, const npoint& pt)
  {
    val[which] = pt;
  }
  void Display(data_container &data) const; // set data for display purpose
  void refine(int nb_iter=1); // does nb_iter steps of Chaikin's algorithm
  void refine_once(void);         // does one step of Chaikin's algorithm
  nchaikin* clone(void) const
  {
    return new nchaikin(*this);
  }
};

#endif // __NCHAIKIN_H
