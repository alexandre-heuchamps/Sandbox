// Gnurbs - A curve and surface library
// Copyright (C) 2008-2017 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//
// Author: Christophe Leblanc.
//

#ifndef __DOOSABIN_H
#define __DOOSABIN_H

#include "nsurface.h"
#include "linear_algebra.h"

// Doo-Sabin scheme for quadratic meshes.
class doosabin: public nparametricsurface
{
protected:
  std::vector<npoint> val; // control points (ordered in u then in v)
  int nCPu; // Number of vertices in the u direction
  int nCPv; // Number of vertices int the v direction

public:
  doosabin(int nCPu_, int nCPv_);

  virtual int degree(void) const { return 2; }
  virtual int degree_u(void) const { return 2; }
  virtual int degree_v(void) const { return 2; }
  virtual double min_u() const { return 0 ; }
  virtual double max_u() const { return 1;  }
  virtual double min_v() const { return 0 ; }
  virtual double max_v() const  { return 1; }
  virtual int nb_CP() const { return nCPu*nCPv; }
  virtual int nb_CP_u(int iv=0) const { return nCPu; }
  virtual int nb_CP_v(int iu=0) const { return nCPv; }

  virtual npoint CP(int whichu,int whichv) const
  {
    return val[whichu+nCPu*whichv];
  }
  virtual npoint CP(int which) const
  {
    return val[which];
  }
  virtual npoint& CP(int whichu,int whichv)
  {
    return val[whichu+nCPu*whichv];
  }
  virtual npoint& CP(int which)
  {
    return val[which];
  }
  virtual void set_CP(int whichu,int whichv,const npoint& pt)
  {
    val[whichu+nCPu*whichv]=pt;
  }
  virtual void set_CP(int which,const npoint& pt)
  {
    val[which]=pt;
  } 

  virtual void P(double u, double v, npoint& ret) const;
  virtual void refine(int nb_times);
  virtual nsurface* clone() const
  { return new doosabin(*this); }

protected:
  int findspan(double u, double start, double end, int nb) const;
  void extract_3x3_patch(int i, int j, npoint patch[3][3]) const;
  void sub_3x3_patch(const npoint patch[3][3], const Square_Matrix &Su,
                     const Square_Matrix &Sv, npoint Q[3][3]) const;
  void sew_sub_patches(const npoint Q00[3][3], const npoint Q01[3][3], 
                       const npoint Q10[3][3], const npoint Q11[3][3], 
                       npoint rpatch[4][4]) const;
  void refine_once();
};

#endif // __DOOSABIN_H
