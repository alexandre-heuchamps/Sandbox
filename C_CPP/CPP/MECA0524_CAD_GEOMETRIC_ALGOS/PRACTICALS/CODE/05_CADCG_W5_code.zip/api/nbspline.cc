// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nbspline.h"

#include <cmath>
#include <iostream>

void nbspline::P(double u_,npoint& ret) const
{
  curvepoint(u_,ret);
}

int nbspline::findspan(double u) const
{
  int inter;
  if (u>=knots[nCP]) return nCP-1;
  if (u<=knots[deg]) return deg;
  int low=deg,high=nCP+1;
  int mid= (low+high) /2;
  while ((u<knots[mid-1]) || (u>= knots[mid]))
  {
    if (u<knots[mid-1]) high=mid;
    else low=mid;
    mid= (low+high) /2;
  }
  inter = mid-1;
  return inter;
}


void nbspline::basisfuns(int i, double u,std::vector<double> &N) const
{
  std::vector<double> left(deg+1);
  std::vector<double> right(deg+1);
  N[0]=1.0;
  for (int j=1;j<=deg;++j)
  {
    left[j]=u-knots[i+1-j];
    right[j]=knots[i+j]-u;
    double saved=0.0;
    for (int r=0;r<j;++r)
    {
      double temp=N[r]/ (right[r+1]+left[j-r]);
      N[r]=saved+right[r+1]*temp;
      saved=left[j-r]*temp;
    }
    N[j]=saved;
  }
}

void nbspline::curvepoint(double u,npoint &C) const
{
  std::vector<double> N(deg+1);
  int span=findspan(u);
  basisfuns(span,u,N);
  for (int i=0;i<4;++i) C[i]=0.;
  for (int i=0;i<=deg;++i)
  {
    C=C+val[span-deg+i]*N[i];
  }
}

void nbspline::findspanmult(double u,int &k,int &s)
{
  s=0;
  if (u>=knots[nCP])
  {
    k=nCP;
    while (knots[nCP]==knots[k+s])
    {
      s++;
      if (s>deg) break;
    }
    return;
  }
  if (u<=knots[deg])
  {
    k=deg;
    while (knots[deg]==knots[k-s])
    {
      s++;
      if (s>deg) break;
    }
    return;
  }
  int low=deg,high=nCP;
  int mid= (low+high) /2;
  while ((u<knots[mid]) || (u>= knots[mid+1]))
  {
    if (u<knots[mid]) high=mid;
    else low=mid;
    mid= (low+high) /2;
  }
  k=mid;
  while (u==knots[k-s])
  {
    s++;
    if (s>deg) break;
  }
}
