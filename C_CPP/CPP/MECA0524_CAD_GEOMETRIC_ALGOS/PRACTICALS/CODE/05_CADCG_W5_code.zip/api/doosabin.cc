// Gnurbs - A curve and surface library
// Copyright (C) 2008-2017 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//
// Author: Christophe Leblanc. MaJ : Alex Bolyn
//

#include "doosabin.h"
#include <math.h>

doosabin::doosabin(int nCPu_, int nCPv_): nCPu(nCPu_), nCPv(nCPv_), val(nCPu_*nCPv_)
{}

void doosabin::P(double u, double v, npoint& ret) const
{
  // Find in which quadrilateral patch we are...
  // Note: a patch is not planar in general.
  const int i = findspan(u, min_u(), max_u(), nb_CP_u());
  const int j = findspan(v, min_v(), max_v(), nb_CP_v());
  const int ip1 = i+1;
  const int jp1 = j+1;

  const npoint P00 = CP(i, j);
  const npoint P10 = CP(ip1, j);
  const npoint P01 = CP(i, jp1);
  const npoint P11 = CP(ip1, jp1);

  // Bilinear interpolation of the current patch.
  const double stepu = (max_u()-min_u())/(nb_CP_u()-1);
  const double stepv = (max_v()-min_v())/(nb_CP_v()-1);

  const double u0 = i*stepu;
  const double u1 = ip1*stepu;
  const double v0 = j*stepv;
  const double v1 = jp1*stepv;

  const npoint f0 = (u1-u)/(u1-u0)*P00 + (u-u0)/(u1-u0)*P10;
  const npoint f1 = (u1-u)/(u1-u0)*P01 + (u-u0)/(u1-u0)*P11;
  ret = (v1-v)/(v1-v0)*f0 + (v-v0)/(v1-v0)*f1;;
}

int doosabin::findspan(double u, double start, double end, int nb) const
{
  if(u <= start) return 0;
  if(u >= end)   return nb-2;

  int low = 0, high = nb;
  int mid = (low + high)/2;

  const double step = (end-start)/(nb-1);

  while(u < (mid-1)*step || u >= mid*step)
  {
    if(u < (mid-1)*step) high = mid;
    else low = mid;
    mid = (high + low)/ 2;
  }

  return (mid-1);
}

void doosabin::refine(int nb_times)
{
  for(int i = 0; i < nb_times; ++i)
  {
    refine_once() ;
  }
}

void doosabin::extract_3x3_patch(int i, int j, npoint patch[3][3]) const
{
  int a, b;
  a = 0;

  for(int ii = i; ii < i+3; ii++)
  {
    b = 0;

    for(int jj = j; jj < j+3; jj++)
    {
      patch[a][b] = CP(ii, jj);
      b++;
    }

    a++;
  }
}

void doosabin::sub_3x3_patch(const npoint patch[3][3], const Square_Matrix &S1,
                             const Square_Matrix &S2, npoint Q[3][3]) const
{
  // Given a patch of 3x3 = 9 control points,
  // this function computes the control points Q of one of the
  // four "sub-patches" Q00, Q01, Q10 and Q11
  // corresponding to each quadrant of the initial "patch".

  // DELETE the following line when implementing
  for(int i = 0; i < 3; ++i) for(int j = 0; j < 3; j++) Q[i][j] = npoint(0, 0, 0, 1);

  // INSERT your code here.

}

void doosabin::sew_sub_patches(const npoint Q00[3][3], const npoint Q01[3][3],
  const npoint Q10[3][3], const npoint Q11[3][3], npoint rpatch[4][4]) const
{
  // Given four 3x3 patches Q00, Q01, Q10 and Q11 for each quadrant,
  // assemble them in order to return into variable 'rpatch' one
  // 4x4 patch.

  // INSERT your code here.
}

// Note: this code is far from being optimized: lot of redundant points are computed.
// Refinement function
void doosabin::refine_once()
{
  // Compute the number of 3x3 patches along the u and v directions.
  const int npatches_u = nCPu-2;
  const int npatches_v = nCPv-2;

  // New control points
  const int new_nCPu = 2*(nCPu-1);
  const int new_nCPv = 2*(nCPv-1);
  std::vector<npoint> new_val(new_nCPu*new_nCPv);

  // Set S matrices.
  Square_Matrix Su(3), Sut(3), Sv(3), Svt(3);

  /*
   INSERT your code here:
   compute the entries of the four 3x3 matrices S.
   Tip : see nutil/linear_algebra.cpp
  */

  // Loop over the 3x3 patches
  for(int i = 0; i < npatches_u; ++i)
  {
    for(int j = 0; j < npatches_v; ++j)
    {
      // Get the current 3x3 patch
      npoint patch[3][3];
      extract_3x3_patch(i, j, patch);

      // Refine the current 3x3 patch into four 3x3 patches.
      // IMPLEMENT function sub_3x3_patch (see above) !
      npoint Q00[3][3], Q01[3][3], Q10[3][3], Q11[3][3];
      sub_3x3_patch(patch, Su, Sut, Q00);
      sub_3x3_patch(patch, Su, Svt, Q01);
      sub_3x3_patch(patch, Sv, Sut, Q10);
      sub_3x3_patch(patch, Sv, Svt, Q11);

      // Sew the four 3x3 patches together.
      // IMPLEMENT function sew_sub_patches (see above) !
      npoint refined_patch[4][4];
      sew_sub_patches(Q00, Q01, Q10, Q11, refined_patch);

      // Update the list of new control points.
      for(int k = 0; k < 4; ++k)
        for(int l = 0; l < 4; ++l)
          new_val[(k+2*i)+new_nCPu*(l+2*j)] = refined_patch[k][l];
    }
  }

  // Update the surface.
  val = new_val;
  nCPu = new_nCPu;
  nCPv = new_nCPv;
}
