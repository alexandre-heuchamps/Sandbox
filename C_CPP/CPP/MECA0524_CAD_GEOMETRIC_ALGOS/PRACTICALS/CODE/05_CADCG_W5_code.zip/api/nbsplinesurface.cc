// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nbsplinesurface.h"

#include <cmath>
#include <iostream>


int nbsplinesurface::degree(void) const
{
  if (degu>degv) return degu;
  else return degv;
}

int nbsplinesurface::findspan(const std::vector<double> &knots,int nknots,int deg,double u) const
{
  int inter;
  int nCP=nknots-deg-1;
  if (u>=knots[nCP]) return nCP-1;
  if (u<=knots[deg]) return deg;
  //else
  //{
  int low=deg,high=nCP+1;
  int mid= (low+high) /2;
  while ((u<knots[mid]) || (u>= knots[mid+1]))
    //while ((u<knots[mid-1]) || (u>= knots[mid]))
  {
    if (u<knots[mid]) high=mid;
    else low=mid;
    //if (u<knots[mid-1]) high=mid; else low=mid;
    mid= (low+high) /2;
  }
  //inter = mid - 1;
  //}
  return mid;
  //return inter;
}


void nbsplinesurface::findspanmult(const std::vector<double> &knots,int nknots, int deg,double u,int &k,int &s)
{
  int nCP=nknots-deg-1;
  s=0;
  if (u>=knots[nCP])
  {
    k=nCP;
    while (knots[nCP]==knots[k+s])
    {
      s++;
      if (s>deg) break;
    }
    return;
  }
  if (u<=knots[deg])
  {
    k=deg;
    while (knots[deg]==knots[k-s])
    {
      s++;
      if (s>deg) break;
    }
    return;
  }
  int low=deg,high=nCP;
  int mid= (low+high) /2;
  while ((u<knots[mid]) || (u>= knots[mid+1]))
  {
    if (u<knots[mid]) high=mid;
    else low=mid;
    mid= (low+high) /2;
  }
  k=mid;
  while (u==knots[k-s])
  {
    s++;
    if (s>deg) break;
  }
}





void nbsplinesurface::basisfuns(const std::vector<double> &knots,int nknots, int deg, int i, double para, std::vector<double> &N) const
{
  N[0]=1.0;
  std::vector<double> left(deg+1);
  std::vector<double> right(deg+1);
  for (int j=1;j<=deg;++j)
  {
    left[j]=para-knots[i+1-j];
    right[j]=knots[i+j]-para;
    double saved=0.0;
    for (int r=0;r<j;++r)
    {
      double temp=N[r]/ (right[r+1]+left[j-r]);
      N[r]=saved+right[r+1]*temp;
      saved=left[j-r]*temp;
    }
    N[j]=saved;
  }
}




void nbsplinesurface::gradbasisfuns(const std::vector<double> &knots,int nknots,int deg,int i, double u,int n,std::vector<std::vector<double> > &N) const
{
  std::vector<double> left(deg+1);
  std::vector<double> right(deg+1);
  std::vector<std::vector<double> > ndu(deg+1);
  for (int j=0;j<=deg;++j) ndu[j].resize(deg+1);
  std::vector<double> a[2];
  for (int j=0;j<2;++j) a[j].resize(deg+1);
  ndu[0][0]=1.0;
  for (int j=1;j<=deg;++j)
  {
    left[j]=u-knots[i+1-j];
    right[j]=knots[i+j]-u;
    double saved=0.0;
    for (int r=0;r<j;++r)
    {
      ndu[j][r] = right[r+1]+left[j-r];
      double temp=ndu[r][j-1]/ ndu[j][r];
      ndu[r][j]=saved+right[r+1]*temp;
      saved=left[j-r]*temp;
    }
    ndu[j][j]=saved;
  }
  for (int j=0;j<=deg;++j)
  {
    N[0][j]=ndu[j][deg];
  }
  int r;
  for (r=0;r<=deg;++r)
  {
    int s1=0,s2=1;
    a[0][0]=1.0;
    for (int k=1;k<=n;++k)
    {
      double d=0.0;
      int rk=r-k,pk=deg-k;
      if (r>=k)
      {
        a[s2][0]=a[s1][0]/ndu[pk+1][rk];
        d=a[s2][0]*ndu[rk][pk];
      }
      int j,j1,j2;
      if (rk>=-1) j1=1;
      else j1=-rk;
      if (r-1<=pk) j2=k-1;
      else j2=deg-r;
      for (j=j1;j<=j2;++j)
      {
        a[s2][j]=(a[s1][j]-a[s1][j-1])/ndu[pk+1][rk+j];
        d+=a[s2][j]*ndu[rk+j][pk];
      }
      if (r<=pk)
      {
        a[s2][k] = -a[s1][k-1]/ndu[pk+1][r];
        d+=a[s2][k]*ndu[r][pk];
      }
      N[k][r]=d;
      j=s1;s1=s2;s2=j;
    }
  }
  r=deg;
  for (int k=1;k<=n;++k)
  {
    for (int j=0;j<=deg;++j) N[k][j]*=r;
    r*=(deg-k);
  }
}



void nbsplinesurface::curvepoint(double u, double v, npoint &C) const
{
  std::vector<double> Nu(degu+1);
  std::vector<double> Nv(degv+1);
  int spanu=findspan(knotsu,nknotsu,degu,u);
  int spanv=findspan(knotsv,nknotsv,degv,v);
  basisfuns(knotsu,nknotsu,degu,spanu,u,Nu);
  basisfuns(knotsv,nknotsv,degv,spanv,v,Nv);
  for (int i=0;i<4;++i) C[i]=0.;
  for (int i=0;i<=degu;++i)
  {
    int debu=spanu-degu+i;
    for (int j=0;j<=degv;++j)
    {
      int debv=spanv-degv+j;
      C=C+val[debu+nCPu*debv]*Nu[i]*Nv[j];
    }
  }
}


void nbsplinesurface::dercurvepoint(double u, double v, int nu,int nv,npoint &C) const
{
  std::vector<std::vector<double> > Nu(nu+1);
  std::vector<std::vector<double> > Nv(nv+1);
  for (int i=0;i<nu+1;++i) Nu[i].resize(degu+1);
  for (int i=0;i<nv+1;++i) Nv[i].resize(degv+1);
  int spanu=findspan(knotsu,nknotsu,degu,u);
  int spanv=findspan(knotsv,nknotsv,degv,v);
  gradbasisfuns(knotsu,nknotsu,degu,spanu,u,nu,Nu);
  gradbasisfuns(knotsv,nknotsv,degv,spanv,v,nv,Nv);
  for (int i=0;i<4;++i) C[i]=0.;
  for (int i=0;i<=degu;++i)
  {
    int debu=spanu-degu+i;
    for (int j=0;j<=degv;++j)
    {
      int debv=spanv-degv+j;
      C=C+val[debu+nCPu*debv]*Nu[nu][i]*Nv[nv][j];
    }
  }
}

void nbsplinesurface::P(double u,double v, npoint& ret) const
{
  curvepoint(u, v, ret);
}

void nbsplinesurface::dPdu(double u,double v, npoint& ret) const
{
  dercurvepoint(u, v, 1,0,ret);
}

void nbsplinesurface::dPdv(double u,double v, npoint& ret) const
{
  dercurvepoint(u, v,0,1, ret);
}

void nbsplinesurface::d2Pdu2(double u,double v, npoint& ret) const
{
  dercurvepoint(u, v,2,0, ret);
}

void nbsplinesurface::d2Pdv2(double u,double v, npoint& ret) const
{
  dercurvepoint(u, v, 0,2,ret);
}

void nbsplinesurface::d2Pdudv(double u,double v, npoint& ret) const
{
  dercurvepoint(u, v,1,1, ret);
}


void nbsplinesurface::saturate_u()
{
  int curn=degu;
  double curk;
  while (curn< (nknotsu-degu))
  {
    curk=knotsu[curn];
    insertknot_u(curk,degu);
    while ((knotsu[curn]==curk) && (curn< (nknotsu-degu))) curn++;
  }
}

void nbsplinesurface::saturate_v()
{
  int curn=degv;
  double curk;
  while (curn< (nknotsv-degv))
  {
    curk=knotsv[curn];
    insertknot_v(curk,degv);
    while ((knotsv[curn]==curk) && (curn< (nknotsv-degv))) curn++;
  }
}

void nbsplinesurface::insertknot_u(double u,int r)
{
  int k,s;
  findspanmult(knotsu,nknotsu,degu,u,k,s);
  if ((r+s) >degu) r=degu-s;
  if (r>0)
  {
    insertknotu_(u,k,s,r);
  }
}

void nbsplinesurface::insertknot_v(double v,int r)
{
  int k,s;
  findspanmult(knotsv,nknotsv,degv,v,k,s);
  if ((r+s) >degv) r=degv-s;
  if (r>0)
  {
    insertknotv_(v,k,s,r);
  }
}

void nbsplinesurface::insertknotu_(double u,int k,int s,int r)
{
  std::vector<double> newknots(nknotsu+r);
  nbsplinesurface newval(nCPu+r,1,nCPv,1);
  int newnCP=nCPu+r;
  int newnknots=nknotsu+r;
  int mp=nCPu+degu;

  for (int i=0;i<=k;++i) newknots[i]=knotsu[i];
  for (int i=1;i<=r;++i) newknots[i+k]=u;
  for (int i=k+1;i<=mp;++i) newknots[i+r]=knotsu[i];

  for (int v=0;v<nCPv;++v)
  {
    std::vector<npoint> R(nCPu+r);
    for (int i=0;i<=k-degu;++i) newval.CP(i,v) =CP(i,v);
    for (int i=k-s;i<nCPu;++i) newval.CP(i+r,v) =CP(i,v);
    for (int i=0;i<=degu-s;++i) R[i]=CP(k-degu+i,v);
    int L=0;
    for (int j=1;j<=r;++j)
    {
      L=k-degu+j;
      for (int i=0;i<=degu-j-s;++i)
      {
        double alpha= (u-knotsu[L+i]) / (knotsu[i+k+1]-knotsu[L+i]);
        R[i]=R[i+1]*alpha+R[i]* (1.0-alpha);
      }
      newval.CP(L,v) =R[0];
      newval.CP(k+r-j-s,v) =R[degu-j-s];
    }
    for (int i=L+1;i<k-s;++i)
    {
      newval.CP(i,v) =R[i-L];
    }
  }
  knotsu=newknots;
  val=newval.val;
  nCPu=newnCP;
  nknotsu=newnknots;
}


void nbsplinesurface::insertknotv_(double v,int k,int s,int r)
{
  std::vector<double> newknots(nknotsv+r);
  nbsplinesurface newval(nCPu,1,nCPv+r,1);
  int newnCP=nCPv+r;
  int newnknots=nknotsv+r;
  int mp=nCPv+degv;

  for (int i=0;i<=k;++i) newknots[i]=knotsv[i];
  for (int i=1;i<=r;++i) newknots[i+k]=v;
  for (int i=k+1;i<=mp;++i) newknots[i+r]=knotsv[i];

  for (int u=0;u<nCPu;++u)
  {
    std::vector<npoint> R(nCPv+r);
    for (int i=0;i<=k-degv;++i) newval.CP(u,i) =CP(u,i);
    for (int i=k-s;i<nCPv;++i) newval.CP(u,i+r) =CP(u,i);
    for (int i=0;i<=degv-s;++i) R[i]=CP(u,k-degv+i);
    int L=0;
    for (int j=1;j<=r;++j)
    {
      L=k-degv+j;
      for (int i=0;i<=degv-j-s;++i)
      {
        double alpha= (v-knotsv[L+i]) / (knotsv[i+k+1]-knotsv[L+i]);
        R[i]=R[i+1]*alpha+R[i]* (1.0-alpha);
      }
      newval.CP(u,L) =R[0];
      newval.CP(u,k+r-j-s) =R[degv-j-s];
    }
    for (int i=L+1;i<k-s;++i)
    {
      newval.CP(u,i) =R[i-L];
    }
  }
  knotsv=newknots;
  val=newval.val;
  nCPv=newnCP;
  nknotsv=newnknots;
}

void nbsplinesurface::degree_elevation_u()
{
  saturate_u();
  nbsplinesurface buf;
  buf.nCPu= (nb_CP_u() + (nb_CP_u()-1) /degree_u());
  buf.nCPv=nb_CP_v();
  buf.degu=degu+1;
  buf.degv=degv;
  buf.knotsu.reserve(nb_knots_u() + (nb_knots_u()-2) /degree_u());
  buf.knotsv=knotsv;
  buf.nknotsv=nknotsv;
  buf.val.resize((nb_CP_u() + (nb_CP_u()-1) /degree_u()) *nb_CP_v());
  buf.knotsu.resize(0);
//  buf.val.resize(0);
  int i=0;
  for (;i<nb_knots_u()-1;++i)
  {
    buf.knotsu.push_back(knotsu[i]);
    if ((knotsu[i]-knotsu[i+1]) !=0) buf.knotsu.push_back(knotsu[i]);
  }
  buf.knotsu.push_back(knotsu[i]);
  buf.knotsu.push_back(knotsu[i]);

  for (int v=0;v<nb_CP_v();++v)
  {
    i=0;
    int k=0;
    buf.CP(k,v) =CP(i,v);
    ++k;
    ++i;
    while (i<nb_CP_u())
    {
      for (int j=1;j<=degu;++j)
      {
        buf.CP(k,v) =CP(i-1,v) + ((double)(degu+1.-j) / (degu+1.)) * (CP(i,v)-CP(i-1,v));
        ++k;
        ++i;
      }
      buf.CP(k,v) =CP(i-1,v);
      ++k;
    }
  }
  buf.nknotsu=buf.knotsu.size();
  *this=buf;
}


void nbsplinesurface::degree_elevation_v()
{
  saturate_v();
  nbsplinesurface buf;
  buf.nCPu=nb_CP_u();
  buf.nCPv= (nb_CP_v() + (nb_CP_v()-1) /degree_v());
  buf.degv=degv+1;
  buf.degu=degu;
  buf.knotsv.reserve(nb_knots_v() + (nb_knots_v()-2) /degree_v());
  buf.knotsu=knotsu;
  buf.nknotsu=nknotsu;
  buf.val.resize((nb_CP_v() + (nb_CP_v()-1) /degree_v()) *nb_CP_u());
  buf.knotsv.resize(0);
//  buf.val.resize(0);
  int i=0;
  for (;i<nb_knots_v()-1;++i)
  {
    buf.knotsv.push_back(knotsv[i]);
    if ((knotsv[i]-knotsv[i+1]) !=0) buf.knotsv.push_back(knotsv[i]);
  }
  buf.knotsv.push_back(knotsv[i]);
  buf.knotsv.push_back(knotsv[i]);

  for (int u=0;u<nb_CP_u();++u)
  {
    i=0;
    int k=0;
    buf.CP(u,k) =CP(u,i);
    ++k;
    ++i;
    while (i<nb_CP_v())
    {
      for (int j=1;j<=degv;++j)
      {
        buf.CP(u,k) =CP(u,i-1) + ((double)(degv+1.-j) / (degv+1.)) * (CP(u,i)-CP(u,i-1));
        ++k;
        ++i;
      }
      buf.CP(u,k) =CP(u,i-1);
      ++k;
    }
  }
  buf.nknotsv=buf.knotsv.size();
  *this=buf;
}



void nbsplinesurface::makecoons(const nbspline &Cu0,const nbspline &Cu1,const nbspline &Cv0,const nbspline &Cv1,  nbsplinesurface &S1,nbsplinesurface &S2,nbsplinesurface &S3)
{
  S1.knotsu=Cu0.knots;
  S1.nknotsu=Cu0.nknots;
  S1.nknotsv=4;
  S1.knotsv.resize(4);
  S1.knotsv[0]=S1.knotsv[1]=Cv0.min_u();
  S1.knotsv[2]=S1.knotsv[3]=Cv0.max_u();
  S1.val.resize(2*Cu0.nCP);
  S1.nCPu=Cu0.nCP;
  S1.nCPv=2;
  S1.degu=Cu0.deg;
  S1.degv=1;
  for (int i =0;i<Cu0.nCP;++i)
  {
    S1.CP(i,0) =Cu0.CP(i);
    S1.CP(i,1) =Cu1.CP(i);
  }

  S2.knotsv=Cv0.knots;
  S2.nknotsv=Cv0.nknots;
  S2.nknotsu=4;
  S2.knotsu.resize(4);
  S2.knotsu[0]=S2.knotsu[1]=Cu0.min_u();
  S2.knotsu[2]=S2.knotsu[3]=Cu0.max_u();
  S2.val.resize(2*Cv0.nCP);
  S2.nCPv=Cv0.nCP;
  S2.nCPu=2;
  S2.degv=Cv0.deg;
  S2.degu=1;
  for (int i =0;i<Cv0.nb_CP();++i)
  {
    S2.CP(0,i) =Cv0.CP(i);
    S2.CP(1,i) =Cv1.CP(i);
  }

  S3.nknotsu=4;
  S3.knotsu.resize(4);
  S3.knotsu[0]=S3.knotsu[1]=Cu0.min_u();
  S3.knotsu[2]=S3.knotsu[3]=Cu0.max_u();
  S3.nknotsv=4;
  S3.knotsv.resize(4);
  S3.knotsv[0]=S3.knotsv[1]=Cv0.min_u();
  S3.knotsv[2]=S3.knotsv[3]=Cv0.max_u();
  S3.val.resize(4);
  S3.nCPu=2;
  S3.nCPv=2;
  S3.degu=1;
  S3.degv=1;
  Cu0.P(Cu0.min_u(),S3.CP(0,0));
  Cu0.P(Cu0.max_u(),S3.CP(1,0));
  Cu1.P(Cu1.min_u(),S3.CP(0,1));
  Cu1.P(Cu1.max_u(),S3.CP(1,1));
  int degu=Cu0.degree();
  int degv=Cv0.degree();
  int nku=Cu0.nb_knots();
  int nkv=Cv0.nb_knots();
  for (int i=1;i<degu;++i)
  {
    S2.degree_elevation_u();
    S3.degree_elevation_u();
  }
  for (int i=1;i<degv;++i)
  {
    S1.degree_elevation_v();
    S3.degree_elevation_v();
  }
  for (int i=degu+1;i<nku-degu;++i)
  {
    S2.insertknot_u(Cu0.u(i),1);
    S3.insertknot_u(Cu0.u(i),1);
  }
  for (int i=degv+1;i<nkv-degv;++i)
  {
    S1.insertknot_v(Cv0.u(i),1); // 01/12/ Bug. Was "S2.insertknot_v(Cv0.u(i),1);"
    S3.insertknot_v(Cv0.u(i),1);
  }

  *this=S1;
  for (int i=0;i<nb_CP();++i) CP(i) += (S2.CP(i)-S3.CP(i));
}

void  nbsplinesurface::get_valeur_fonction(int inter, double t, int degre, std::vector<double> &knots,double *grand_n)
{
  double saved;
  grand_n[0]=1.0;
  double *gauche=new double[degre];
  double *droite=new double[degre];
  for (int j=1;j<=degre;j++)
  {
    gauche[j-1]= t-knots[inter-j+1];
    droite[j-1]=knots[inter+j]-t;
    saved=0.0;
    for (int r=0;r<j;r++)
    {
      double temp=grand_n[r]/ (droite[r]+ gauche[j-r-1]);
      grand_n[r]=saved+droite[r]* temp;
      saved=gauche[j-r-1]*temp;
    }
    grand_n[j]=saved;
  }
  delete [] gauche;
  delete [] droite;
}

void  nbsplinesurface::evaluer(double *uv,double *xyz)
{

  int sens = 1;

  double u = uv[0];
  double v = uv[1];

  if (sens==-1) u=min_u() +max_u()-u;

#define P(i,j) val [ (uspan - degu + i) * nCPv + (vspan - degv + j) ]

  int uspan = findspan(knotsu, nknotsu, degu,u);

  int vspan = findspan(knotsv, nknotsv, degv,v);

  double Nu[20];
  //std::vector<double> Nu;
  get_valeur_fonction(uspan,u,degu,knotsu,Nu);

  double Nv[20];
  get_valeur_fonction(vspan,v,degv,knotsv,Nv);

  //OT_VECTEUR_4D temp[20];
  npoint temp[20];

  int l;
  for (l=0;l<=degv;l++)
  {
    //temp[l] =0.0 ;
    temp[l]= npoint(0.0,0.0,0.0,0.0);
    for (int k=0;k<=degu;k++)
    {
      temp[l] += Nu[k]*P(k,l) ;
    }
  }
  npoint sp(0,0,0,0) ;
  for (l=0;l<=degv;l++)
  {
    sp += Nv[l]*temp[l];
  }

  // transform homogeneous coordinates to 3D coordinates
  for (int i=0; i<3; i++)
    xyz[i] = sp[i]/sp.w();

#undef P
}

void  nbsplinesurface::deriver_fonction(int inter,double t,int degre,int dd,std::vector<double> &knots,double *f_deriver)
{
#define f_deriver(i,j) (*(f_deriver+(i)*(degre+1)+j))
#define grand_n(i,j) (*(grand_n+(i)*(degre+1)+j))
#define a(i,j) (*(a+(i)*(dd+1)+j))
  double grand_n[256];
  double saved;
  grand_n(0,0) =1.0;
  double gauche[16];
  double droite[16];
  for (int j=1;j<=degre;j++)
  {
    gauche[j]= t-knots[inter-j+1];
    droite[j]=knots[inter+j]-t;
    saved=0.0;
    for (int r=0;r<j;r++)
    {
      grand_n(j,r) = (droite[r+1]+ gauche[j-r]);
      double temp = grand_n(r,j-1) /grand_n(j,r);

      grand_n(r,j) = saved+droite[r+1]*temp;
      saved=gauche[j-r]*temp;
    }
    grand_n(j,j) =saved;
  }
  for (int j=0;j<=degre;j++)
  {
    f_deriver(0,j) = grand_n(j,degre);
  }
  double a[256];
  for (int r=0;r<=degre;r++)
  {
    int s1=0;
    int s2=1;
    a(0,0) =1.0;
    for (int k=1;k<=dd; k++)
    {
      double d=0.0;
      int rk=r-k;
      int pk=degre-k;
      if (r>=k)
      {
        a(s2,0) =a(s1,0) /grand_n(pk+1,rk);
        d= a(s2,0) * grand_n(rk,pk);
      }
      int j1;
      int j2;
      if (rk>=-1)   j1=1;
      else j1= -rk;
      if (r-1<=pk)  j2=k-1;
      else j2=degre-r;
      for (int j=j1;j<=j2;j++)
      {
        a(s2,j) = (a(s1,j)-a(s1,j-1)) /grand_n(pk+1,rk+j);
        d+=a(s2,j) *grand_n(rk+j,pk);
      }
      if (r<=pk)
      {
        a(s2,k) = -a(s1,k-1) /grand_n(pk+1,r);
        d+=a(s2,k) *grand_n(r,pk);
      }
      f_deriver(k,r) =d;
      int j=s1;
      s1=s2;
      s2=j;
    }
  }
  int r=degre;
  for (int k=1;k<=dd;k++)
  {
    for (int j=0;j<=degre;j++)
    {
      f_deriver(k,j) *=r;
    }
    r*= (degre-k);
  }
#undef f_deriver
#undef grand_n
#undef a
}


void nbsplinesurface::binomialCoef(double * Bin, int d)
{
  int n,k;
  // Setup the first line
  Bin[0] = 1.0 ;
  for (k=d-1;k>0;--k)
    Bin[k] = 0.0 ;
  // Setup the other lines
  for (n=0;n<d-1;n++)
  {
    Bin[(n+1) *d+0] = 1.0 ;
    for (k=1;k<d;k++)
      if (n+1<k)
        Bin[(n+1) *d+k] = 0.0 ;
      else
        Bin[(n+1) *d+k] = Bin[n*d+k] + Bin[n*d+k-1] ;
  }
}

void  nbsplinesurface::deriver_bs_kieme(int nb_ptsctr_u,int degre_u,std::vector<double> &knots_u,int nb_ptsctr_v,int degre_v,std::vector<double> &knots_v,double u,double v,int d,npoint * skl)
{
#define skl(i,j) skl[(i)*(d+1)+j]
#define Nu(i,j) Nu[(i)*(degre_u+1)+j]
#define Nv(i,j) Nv[(i)*(degre_v+1)+j]
#define P(i,j) val[(i)*(nb_ptsctr_v)+j]

  int i,j,k,l,s,r,dd;

  int du = std::min(d,degre_u);
  for (k=degre_u+1;k<=d;k++)
  {
    for (int l=0;l<=d-k;k++)
    {
      skl(k,l) =npoint(0.0,0.0,0.0,0.0);
    }
  }
  int dv = std::min(d,degre_v);
  for (l=degre_v+1;l<=d;l++)
  {
    for (k=0;k<=d-l;k++)
    {
      skl(k,l) =npoint(0.0,0.0,0.0,0.0);
    }
  }

  int  inter_u = findspan(knotsu, nknotsu, degu,u);
  double Nu [ 256 ];
  deriver_fonction(inter_u,u,degre_u,du,knots_u,Nu);

  int  inter_v = findspan(knotsv, nknotsv, degv,v);
  double Nv [ 256 ];
  deriver_fonction(inter_v,v,degre_v,dv,knots_v,Nv);

  npoint temp [ 16 ];
  for (k=0; k<=du;k++)
  {
    for (s=0; s<=degre_v;s++)
    {
      temp[s]=npoint(0.0,0.0,0.0,0.0);
      for (r=0; r<=degre_u;r++)
        temp[s]+=P((inter_u-degre_u+r), (inter_v-degre_v+s)) *Nu(k,r);
    }
    dd = std::min(d-k,dv);
    for (l=0; l<=dd;l++)
    {
      skl(k,l) = npoint(0.0,0.0,0.0,0.0);
      for (s=0; s<=degre_v;s++)
        skl(k,l) += temp[s]*Nv(l,s);
    }
  }

#undef skl
#undef f_deriver_u
#undef f_deriver_v
#undef P
}

void  nbsplinesurface::deriver_kieme(double *uv,int d,npoint *skl)
{
#define skl(i,j) (*(skl+(i)*(d+1)+j))
#define ders(i,j) (*(ders+(i)*(d+1)+j))
  double u = uv[0];
  double v = uv[1];
  int i,j,k,l;
  npoint pv,pv2;

  npoint ders [256];

  double Bin[256];
  int dbin=d+1;
  binomialCoef(Bin, dbin);
#define Bin(i,j) (*(Bin+(i)*(dbin)+j))

  deriver_bs_kieme(nCPu,degu,knotsu,nCPv,degv,knotsv,u,v,d,ders);

  for (k=0;k<=d;++k)
  {
    for (l=0;l<=d-k;++l)
    {
      pv = ders(k,l);
      for (j=1;j<=l;j++)
        pv -= Bin(l,j) *ders(0,j).w() *skl(k,l-j) ;
      for (i=1;i<=k;i++)
      {
        pv -= Bin(k,i) *ders(i,0).w() *skl(k-i,l) ;
        pv2 = npoint(0.0,0.0,0.0,0.0);
        for (j=1;j<=l;j++)
          pv2 += Bin(l,j) *ders(i,j).w() *skl(k-i,l-j) ;
        pv -= Bin(k,i) *pv2 ;
      }
      skl(k,l) = pv;
      //skl(k,l) /= ders[0].w();
      skl(k,l) = npoint(skl(k,l) /ders[0].w());
    }
  }
#undef skl
#undef ders
#undef Bin
}

void  nbsplinesurface::deriver_seconde(double *uv,double* xyzduu,double* xyzduv,double* xyzdvv,double *xyz, double *xyzdu, double *xyzdv)
{

  int sens =1;

#define skl(i,j) skl[(i)*(3)+j]
  npoint skl[9];

  double uvl[3];
  uvl[0]=uv[0];
  uvl[1]=uv[1];
//if (sens==-1) uvl[0]=min_u()+max_u()-uvl[0];

  deriver_kieme(uvl,2,skl);

  for (int i=0; i<3; i++)
    xyzduu[i]=skl(2,0)[i];

  for (int i=0; i<3; i++)
    xyzduv[i] = sens * skl(1,1)[i];

  for (int i=0; i<3; i++)
    xyzdvv[i]=skl(0,2)[i];

  if ((xyzdu!=NULL) && (xyzdv!=NULL))
  {
    for (int i=0; i<3; i++)
      xyzdu[i] = sens * skl(1,0)[i];

    for (int i=0; i<3; i++)
      xyzdv[i]=skl(0,1)[i];
  }
  if (xyz!=NULL)
  {
    for (int i=0; i<3; i++)
      xyz[i]=skl(0,0)[i];
  }

  unsigned kk, kkk;
  double LIMITE = 1E99;
  for (kk = 0; kk<3; kk++)
    if ((xyzduu[kk] > LIMITE) || (xyzduv[kk] > LIMITE) || (xyzdvv[kk] > LIMITE))
      break;
  if (kk < 3)
  {
    deriver_seconde(uv,xyzduu,xyzduv,xyzdvv,xyz, xyzdu, xyzdv);
    //printf("pb");
  }

#undef skl
}


void  nbsplinesurface::inverser(double *uv,double *xyz,double precision)
{
  int code=0;
  int num_point= (nb_CP_u() +nb_CP_v()) /2;
  do
  {
    code=inverser2(uv,xyz,num_point,precision);
    num_point=num_point*2;
  }
  while (code==0&&num_point<1500);
}

int  nbsplinesurface::inverser2(double *uv,double *xyz,int num_test, double precision)
{
  double uvi[2];
  double xyz1[3];
  double xyzdu[3];
  double xyzdv[3];
  double xyzduu[3];
  double xyzduv[3];
  double xyzdvv[3];
//OT_VECTEUR_3D Pt(xyz[0],xyz[1],xyz[2]);
  npoint3 Pt(xyz[0],xyz[1],xyz[2]);
  double a[4];
  double delta[2];
  double b[9];
  double delta_u;
  double delta_v;
  double ui;
  double vi;

  double distance_ref=1e308;
  int refu;
  int refv;

  for (int ii=0;ii<num_test+1;ii++)
  {
    double u=min_u() +ii*1./num_test* (max_u()-min_u());
    uvi[0]=u;
    for (int jj=0;jj<num_test+1;jj++)
    {
      double v=min_v() +jj*1./num_test* (max_v()-min_v());
      uvi[1]=v;
      evaluer(uvi,xyz1);

      npoint3 S(xyz1[0],xyz1[1],xyz1[2]);
      npoint3 Distance = S-Pt;
      //double longueur=Distance.get_longueur2();
      double longueur = Distance.x() *Distance.x() + Distance.y() *Distance.y() + Distance.z() *Distance.z();
      if (longueur<distance_ref)
      {
        distance_ref=longueur;
        refu=ii;
        refv=jj;
      }
    }
  }

  double uii=min_u() +refu*1./num_test* (max_u()-min_u());
  double vii=min_v() +refv*1./num_test* (max_v()-min_v());
  int compteur = 0;
  do
  {
    compteur++;
    ui=uii;
    vi=vii;
    uvi[0]=ui;
    uvi[1]=vi;
    deriver_seconde(uvi,xyzduu,xyzduv,xyzdvv,xyz1,xyzdu,xyzdv);
    npoint3 S(xyz1[0],xyz1[1],xyz1[2]);
    npoint3 Su(xyzdu[0],xyzdu[1],xyzdu[2]);
    npoint3 Sv(xyzdv[0],xyzdv[1],xyzdv[2]);
    npoint3 Suu(xyzduu[0],xyzduu[1],xyzduu[2]);
    npoint3 Suv(xyzduv[0],xyzduv[1],xyzduv[2]);
    npoint3 Svv(xyzdvv[0],xyzdvv[1],xyzdvv[2]);
    npoint3 Distance = S-Pt;
    double longueur2_u = Su.x() *Su.x() + Su.y() *Su.y() + Su.z() *Su.z();
    double Distance_Suu = Distance.x() *Suu.x() + Distance.y() *Suu.y() + Distance.z() *Suu.z();
    a[0]=longueur2_u+Distance_Suu;
    double Distance_Suv = Distance.x() *Suv.x() + Distance.y() *Suv.y() + Distance.z() *Suv.z();
    a[1]=Su*Sv+Distance_Suv;
    a[2]=Su*Sv+Distance_Suv;
    double longueur2_v = Sv.x() *Sv.x() + Sv.y() *Sv.y() + Sv.z() *Sv.z();
    double Distance_Svv = Distance.x() *Svv.x() + Distance.y() *Svv.y() + Distance.z() *Svv.z();
    a[3]=longueur2_v+Distance_Svv;
    b[0]=Distance*Su;
    b[0]=-b[0];
    b[1]=Distance*Sv;
    b[1]=-b[1];
    double denominateur_delta= (a[0]*a[3]-a[2]*a[1]);
    if (fabs(denominateur_delta) < ((fabs(a[0]) +fabs(a[1]) +fabs(a[2]) +fabs(a[3])) *1e-12))
      return 0;
    delta_u= (b[0]*a[3]-b[1]*a[1]) /denominateur_delta;
    delta_v= (a[0]*b[1]-a[2]*b[0]) /denominateur_delta;
    if (fabs(delta_u) >max_u()-min_u()) return 0;
    if (fabs(delta_v) >max_v()-min_v()) return 0;
    if (Su.norm2() >1E-14)
      uii=ui+delta_u;
    else
      uii=ui;
    if (Sv.norm2() >1E-14)
      vii=vi+delta_v;
    else
      vii=vi;
    /*        if (periodique_u==0)
                    {
                    if(uii<umin) uii=umin;
                    if(uii>umax) uii=umax;
                    }
            if (periodique_v==0)
                    {
                    if(vii<vmin) vii=vmin;
                    if(vii>vmax) vii=vmax;
                    }
            if (periodique_u==1)
                    {
                    if (uii<umin) uii=umax - (umin-uii);
                    if (uii>umax) uii=umin + (uii-umax);
                    }
            if (periodique_v==1)
                    {
                    if (vii<vmin) vii=vmax - (vmin-vii);
                    if (vii>vmax) vii=vmin + (vii-vmax);
                    }*/

    delta_u=uii-ui;
    delta_v=vii-vi;
    if (compteur>500) return 0;
  }

  while ((fabs(delta_u) >precision) || (fabs(delta_v) >precision));
  uv[0]=uii;
  uv[1]=vii;
  return 1;
}

// (m+1 knots)

double nbsplinesurface::Nip(int p,int m,std::vector<double> &knots, int i, double u)
{
  if ((i==0 && u== knots[0]) || (i==m-p-1 && u== knots[m]))
  {
    return 1.0;
  }

  if ((u < knots[i]) || (u > knots[i+p+1]))
  {
    return 0.0;
  }


  double *grand_n=new double[p+1];
  for (int j=0; j<=p; j++)
  {
    if (u >= knots[i+j] && u < knots[i+j+1]) grand_n[j] = 1.0;
    else grand_n[j] = 0.0;

  }

  for (int k=1; k<=p; k++)
  {
    double saved;
    if (grand_n[0] == 0.0) saved = 0.0;
    else saved = ((u-knots[i]) *grand_n[0]) / (knots[i+k]-knots[i]);

    for (int j=0; j<p-k+1; j++)
    {
      double Uleft = knots[i+j+1];
      double Uright = knots[i+j+k+1];
      if (grand_n[j+1] == 0.0)
      {
        grand_n[j] = saved;
        saved =0.0;
      }
      else
      {
        double temp = grand_n[j+1]/ (Uright - Uleft);
        grand_n[j] = saved + (Uright - u) *temp;
        saved = (u-Uleft) *temp;
      }

    }

  }

  return grand_n[0];

  delete [] grand_n;

}
