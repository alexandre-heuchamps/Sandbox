// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NDISPLAY_H
#define __NDISPLAY_H

#include "nutilconfig.h"
#include "nutil.h"

#ifdef INTERFACE_TYPE_VTK
#include "vtkdisplay.h"
typedef vtkdisplay ndisplay ;
#endif

#ifdef INTERFACE_TYPE_FLTK
#include "fltkdisplay.h"
typedef fltkdisplay ndisplay ;
#endif

#ifdef INTERFACE_TYPE_FILE 
#include "ndisplaytofile.h"
typedef ndisplaytofile ndisplay;
#endif

#ifndef INTERFACE_TYPE_FILE 
#ifndef INTERFACE_TYPE_FLTK
#ifndef INTERFACE_TYPE_VTK

// dummy class that does nothing but allows compilation without graphical output.
// useful for portable code mainly used without GUI
class ndisplay : public ndisplay_base
{
public: 
  virtual ~ndisplay() {}
  ndisplay(color c=color(25, 51, 102,255),char *nom=NULL) {};
  virtual void init_data(const data_container &data) {};   // all
  virtual void init_data(const std::vector<data_container> &data) {};   // all
  virtual void init_data() {};   // self created
  virtual void display() {};   // display loop
};

#endif
#endif
#endif

#endif// __NDISPLAY_H
