// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <fstream>
#include "nbspline.h"
#include "nchaikin.h"
#include "ndisplay.h"
#include "nutil.h"
#include "gnurbscallbacks.h"

// Initialization function prototype
// the complete implementation can be found at the end of the file
// DX and DY are the offsets with respect to the origin
void init_bspline(nbspline &curve,double DX, double DY);
void init_chaikin(nchaikin &curve,double DX,double DY);

// main function

int main(void)
{
  data_container data; 		// Contains data to display
  ndisplay display;			// Display window
  int nCP = 3;				// Number of control points
  nchaikin curve(nCP);                  // Chaikin curve with nCP vertices
  nbspline ref_curve(nCP, 2);           // B-spline

  init_chaikin(curve, 0.0, 0.0);	// Curves initialization
  init_bspline(ref_curve, 0.0, 0.0);

  curve.refine(4);			// Refine curve
  curve.Display(data);			// Display the curves

  properties prop;
  prop.c = color(255, 0, 0);

  gnurbscallbacks CB;
  CB.add_entity(&ref_curve, prop);

  display.setcallbacks(&CB);
  CB.draw();
  CB.datas.push_back(data);
  display.init_data(CB.datas);        // Transfer of the data to display
  display.display();                  // Display loop
  return 0;
}

void init_chaikin(nchaikin &curve,double DX,double DY)
{
  for (int i=0;i< curve.nb_CP();i++)
  {
    double angle=i*n_pi/(curve.nb_CP()-1);
    npoint val;
    val[0]=cos(angle)+DX;
    val[1]=sin(angle)+DY;
    val[2]=0;
    val[3]=1;
    curve.CP(i)=val;
  }
}

void init_bspline(nbspline &curve,double DX, double DY)
{
  for (int i=0;i< curve.nb_CP();i++)
  {
    double angle=i*n_pi/(curve.nb_CP()-1);
    npoint val;
    val[0]=cos(angle)+DX;
    val[1]=sin(angle)+DY;
    val[2]=0;
    val[3]=1;
    curve.CP(i)=val;
  }

  for(int i = 0; i < curve.nb_knots(); i++)
    curve.u(i) = i;
}
