// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <fstream>
#include "nbsplinesurface.h"
#include "doosabin.h"
#include "ndisplay.h"
#include "nutil.h"
#include "gnurbscallbacks.h"

// Initialization function prototype
// the complete implementation can be found at the end of the file
void init_surface(nbsplinesurface &surface);
void init_surface(doosabin &surface);

// main function

int main(void)
{
  data_container data; 			// Contains data to display
  ndisplay display;			// Display window

  int nCPu = 3;				// Number of control points in the u direction
  int nCPv = 3;				// Number of control points in the v direction

  // Catmull-Clark surface
  doosabin surface1(nCPu, nCPv);
  init_surface(surface1);
  surface1.refine(4);

  // Quadratic B-spline surface
  nbsplinesurface surface2(nCPu, 2, nCPv, 2);
  init_surface(surface2);				 // Initialize surface

  // Display the surfaces
  properties prop1;
  prop1.pointsize = 5.f;
  properties prop2;
  prop2.c = color(255, 0, 0);
  prop2.pointsize = 5.f;

  gnurbscallbacks CB;
  CB.add_entity(&surface1, prop1);
  CB.add_entity(&surface2, prop2);

  display.setcallbacks(&CB);
  CB.draw();
  display.init_data(CB.datas);        // Transfer of the data to display
  display.display();                  // Display loop
  return 0;
}

void init_surface(nbsplinesurface &surface)
{
  // Initialize control points
  int i, j;
  const int nCPu = surface.nb_CP_u();
  const int nCPv = surface.nb_CP_v();

  for(i = 0; i < nCPu; ++i) {
    for(j = 0; j < nCPv; ++j) {
      double x = i;
      double y = j;
      double z= 3*sin(j*5*M_PI/(nCPv-1)+M_PI/2)*cos(i*2*M_PI/(nCPu-1)-M_PI/3);

      npoint val(x, y, z, 1);
      surface.set_CP(i, j, val);
    }
  }

  // Initialize knots
  for(i = 0; i < surface.nb_knots_u(); ++i)
      surface.u(i) = i;

  for(j = 0; j < surface.nb_knots_v(); ++j)
      surface.v(j) = j;
}

void init_surface(doosabin &surface)
{
  // Initialize control points
  int i, j;
  const int nCPu = surface.nb_CP_u();
  const int nCPv = surface.nb_CP_v();

  for(i = 0; i < nCPu; ++i) {
    for(j = 0; j < nCPv; ++j) {

      double x = i;
      double y = j;
      double z= 3*sin(j*5*M_PI/(nCPv-1)+M_PI/2)*cos(i*2*M_PI/(nCPu-1)-M_PI/3);

      npoint val(x, y, z, 1);
      surface.set_CP(i, j, val);
    }
  }
}
