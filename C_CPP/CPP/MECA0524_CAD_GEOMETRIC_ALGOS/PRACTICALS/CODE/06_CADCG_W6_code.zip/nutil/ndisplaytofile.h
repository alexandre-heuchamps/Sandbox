// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NDISPLAYTOFILE_H
#define __NDISPLAYTOFILE_H

#include <vector>
#include <iostream>

#include "nutil.h"
#include "ndisplay_base.h"


class ndisplaytofile: public ndisplay_base
{
protected :

public:
  ndisplaytofile(color _c=color(25, 51, 102,255),const char *_name=NULL,std::ostream & out_=std::cout); // constructor
  virtual ~ndisplaytofile(); // destructor
  virtual void init_data(const std::vector<data_container> &data);   // all
  virtual void init_data(const data_container &data);   // one dataset - will be copied
  virtual void init_data();   // self created
  virtual data_container* get_data() { if ((data2)) return &(*data2)[0];else return 0x0;}
  virtual void display();   // display loop
private :
  std::ostream& out;
  const std::vector<data_container> *data;
  std::vector<data_container> *data2; // owned & non const
  color c;
  char *name;
};


#endif// __NDISPLAYTOFILE_H
