// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NFLTKWINDOW_H
#define __NFLTKWINDOW_H

#include <FL/Fl.H>
#include <FL/Fl_Gl_Window.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Output.H>
#include <vector>
class fltkdisplay;
class nglwindow;
class nInfo;
class Fl_Menu_Bar;
class Fl_Button;

class nFltkWindow : public Fl_Double_Window
{
public:
  nFltkWindow(int w_, int h_, const char* t_,fltkdisplay *disp) ;
  virtual ~nFltkWindow();
    void buildMenus ( const Fl_Menu_Item *menuitems_c, void *ptr);
  fltkdisplay *fd;
  nglwindow *gl;
  Fl_Menu_Bar *menu;
  nInfo *info;
  Fl_Button *butX;
  Fl_Button *butY;
  Fl_Button *butZ;
  std::vector<Fl_Menu_Item> menuitems;
  int fontsize;
protected :
  virtual int handle ( int event ); // called from fltk : event handling proc
};

class nglwindow : public Fl_Gl_Window
{
public:
  nglwindow ( int x, int y, int w, int h, fltkdisplay *_caller): Fl_Gl_Window ( x,y,w,h ),
                                                         caller(_caller) {}
  virtual ~nglwindow() {}
  fltkdisplay *caller;
protected:
  virtual void draw ( void ) ; // called from fltk upon redraws
  virtual int handle ( int event ); // called from fltk : event handling proc
private:
};

class nInfo : public Fl_Output
{
public:
  nInfo ( int x, int y, int w, int h): Fl_Output( x,y,w,h ) {}
  virtual ~nInfo() {}
protected:
  virtual int handle ( int event ); // called from fltk : event handling proc
private:
};


#endif // __NFLTKWINDOW_H
