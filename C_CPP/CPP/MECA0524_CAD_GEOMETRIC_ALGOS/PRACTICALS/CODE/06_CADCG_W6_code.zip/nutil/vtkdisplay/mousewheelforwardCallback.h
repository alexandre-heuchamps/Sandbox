// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __MOUSEWHEELFORWARDCALLBACK_H
#define __MOUSEWHEELFORWARDCALLBACK_H

#include "vtkCommand.h"
#include "vtkdisplay.h"

class mousewheelforwardCallback : public vtkCommand
{
private:
  vtkdisplay* myDisplay;
  mousewheelforwardCallback(vtkdisplay * diplay) :vtkCommand()
  {
    myDisplay=diplay;
  }
public:
  static mousewheelforwardCallback* New(vtkdisplay * display)
  {
    return new mousewheelforwardCallback(display);
  }
  void Delete()
  {
    delete this;
  }
  virtual void Execute(vtkObject *caller, unsigned long, void*);
};

#endif
