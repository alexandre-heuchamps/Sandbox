// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <list>
#include <algorithm>
#include <limits>
#include <ctime>

#include "nutil.h"
#include "ndisplay.h"

// Declaration of prototypes

void define_points(std::vector<npoint2> &points, int test_number, int nb_points);
void convex_hull_graham(std::vector<line> &lines, std::vector<npoint2> points);
bool not_a_right_turn(const npoint2 &a, const npoint2 &b, const npoint2 &c);
void compute_statistics(int test_number, int nb_points, double &mean, double &std);
void show_points(data_container &data, const std::vector<npoint2> &points);
void show_lines(data_container &data, const std::vector<line> &lines);

// main function
int main(int argc, char** argv)
{
  // Visualization
  std::vector<data_container> buffer(1);
  data_container &data=buffer[0];
  ndisplay display;                 // Display window

  // Parse input argument
  int test_number = 0; // Test id.
  int start_nb_points; // Starting number of points.
  int end_nb_points;   // Ending number of points.
  int step; // Step between start and end.

  if(argc == 2)
  {
    std::cout << "Usage:" << " test id [none, \'test1\' or \'test2\']"
     << " starting number of points [>2]"
     << " ending number of points [>2]"
     << " step [>0]\n";
    return 1;
  }

  if(argc == 5)
  {
    std::string flag = argv[1];
    std::stringstream s_start(argv[2]);
    std::stringstream s_end(argv[3]);
    std::stringstream s_step(argv[4]);

    s_start >> start_nb_points;
    s_end >> end_nb_points;
    s_step >> step;

    if(start_nb_points < 0)
      start_nb_points = -start_nb_points;

    if(end_nb_points < 0)
      end_nb_points = -end_nb_points;

    if(end_nb_points < start_nb_points)
      std::swap(end_nb_points, start_nb_points);

    if(step < 0) step = -step;
    if(step == 0)
    {
      std::cout << "Step is zero...\n";
      return -1;
    }

    if(flag == "test1")
    {
      test_number = 1;
    }
    else if(flag == "test2")
    {
      test_number = 2;
    }
    else
    {
      std::cout << "Unknown test id...\n";
      return -1;
    }
  }

  if(argc < 5)
  {
    // Points creation
    std::vector<npoint2> points;        // Points from which to find the convex hull
    define_points(points, test_number, -1);        // Define some points in the x-y plane

    std::vector<line> lines;            // Lines forming the convex hull

    convex_hull_graham(lines, points);    // Graham algorithm for computing the convex hull

    // Display the lines
    for(int i = 0; i < lines.size(); ++i)
      std::cout  << "(" << lines[i].pts[0][0] << ", " << lines[i].pts[0][1] << ")"
                 << "-> (" << lines[i].pts[1][0] << ", " << lines[i].pts[1][1] << ")\n";

    show_points(data, points);
    show_lines(data, lines);
    display.init_data(buffer);
    display.display();
  }
  else
  {
    std::vector<int> nb_points;
    std::vector<double> means;
    std::vector<double> stds;

    // Compute statistics for each number of points
    for(int i = start_nb_points; i <= end_nb_points; i += step)
    {
      std::cout << "/****************************/\n"
        << "     Test with " << i << " points\n"
        << "/****************************/\n\n";

      double mean, std;
      compute_statistics(test_number, i, mean, std);

      nb_points.push_back(i);
      means.push_back(mean);
      stds.push_back(std);
    }

    // Save results in a file
    {
      std::string filename = "graham_test";
        filename += (test_number == 1 ? "1" : "2");
        filename += ".txt";

      std::fstream file;
      file.open(filename.c_str(), std::ios::out);

      if(!file.is_open())
      {
        std::cout << "ERROR: can not create file of results\n";
        return -1;
      }

      // Save header.
      file << "\% Number of points\t Mean time (ms)\t Std time (ms)\n";

      for(size_t i = 0; i < nb_points.size(); i++)
        file << nb_points[i] << "\t" << means[i] << "\t" << stds[i] << "\n";

      file.close();
      std::cout << "Results saved in file: " << filename << "\n";
    }
  }

  return 0;
}

// Comparison functor for sorting 2D points.
class PointsCompare2D
{
public:
  bool operator()(const npoint2 &a, const npoint2 &b) const
  {
    if(a[0] != b[0]) return a[0] < b[0];
    else return a[1] < b[1];
  }
};

// Graham algorithm for computing the convex hull of a set of points in the plane.
void convex_hull_graham(std::vector<line> &lines, std::vector<npoint2> points)
{
  // To implement.
  //
  // 'points' are the entry points from which the convex hull has to be computed.
  // 'lines' are the lines defining the convex hull to be outputed.
}

// Add points to a data container for visualizing them
void show_points(data_container &data, const std::vector<npoint2> &points)
{
  // Set some propreties to the points in order to visualize them better...
  properties ptr = data.getproppoints();
  ptr.pointsize = 3;
  data.setproppoints(ptr);

  // To implement: add points to the data_container.
  // (see nutil/ndata.h)
}

// Add lines to a data container for visualizing them
void show_lines(data_container &data, const std::vector<line> &lines)
{
  // TO implement: add lines to the data_container.
  // (see nutil/ndata.h)
}

// Return true if the lines joigning the points 'a', 'b' and 'b', 'c'
// do NOT do a right turn. Return false otherwise.
bool not_a_right_turn(const npoint2 &a, const npoint2 &b, const npoint2 &c)
{
  // To implement: determine if lines a-b and b-c do NOT
  // form a right-turn.
  // Be careful about the case of aligned points.
}

// Defines points from which to define the convex hull.
void define_points(std::vector<npoint2> &points, int test_number, int nb_points)
{
  points.clear();

  if(test_number == 0)
  {
    points.push_back(npoint2(0.75, 0.50));
    points.push_back(npoint2(1.00, 1.00));
    points.push_back(npoint2(1.00, 0.25));
    points.push_back(npoint2(1.20, 0.50));
    points.push_back(npoint2(1.50, 0.75));
    points.push_back(npoint2(1.50, 0.50));
    points.push_back(npoint2(1.50, 1.00));
    points.push_back(npoint2(1.75, 0.30));
    points.push_back(npoint2(2.00, 1.00));
    points.push_back(npoint2(2.00, 0.60));
    points.push_back(npoint2(2.00, 0.25));
    points.push_back(npoint2(2.25, 0.50));
  }
  else if(test_number == 1)
  {
    // "Random" points on a square.
    std::srand(std::time(NULL));

    for(int i = 0; i < nb_points; i++)
    {
      const double x = std::rand()/double(RAND_MAX);
      const double y = std::rand()/double(RAND_MAX);
      points.push_back(npoint2(x, y));
    }
  }
  else if(test_number == 2)
  {
    // "Random" point on a circle.
    std::srand(std::time(NULL));

    for(int i = 0; i < nb_points; i++)
    {
      const double theta = std::rand()/double(RAND_MAX) * 2.0 * M_PI;
      points.push_back(npoint2(cos(theta), sin(theta)));
    }
  }
}

// Do some statistics on the performance of the algorithm.
void compute_statistics(int test_number, int nb_points, double &mean, double &std)
{
  if(test_number == 1)
    std::cout << "(Pseudo-) random points in the square [0, 1] x [0, 1]\n\n";
  else if(test_number == 2)
    std::cout << "(Pseudo-) random points on the unit circle\n\n";
  else
  {
    std::cout << "Unrecognized test number " << test_number << ", bailing out\n";
    return;
  }

  const int nb_samples = 20;
  mean = 0.0;
  std = 0.0;

  std::vector<double> time_measure;
  time_measure.reserve(nb_samples);

  // Measure mean time over each sample of random points.
  for(int sample = 0; sample < nb_samples; ++sample)
  {
    std::cout << "Sample " << (sample+1) << "/" << nb_samples << " with " << nb_points << " points\n";

    // Time measure
    clock_t start, end;

    // Point creation
    std::vector<npoint2> points; // Points from which to find the convex hull
    define_points(points, test_number, nb_points);
    std::vector<line> lines;     // Lines forming the convex hull

    start = clock();
    convex_hull_graham(lines, points); // Graham algorithm for computing the convex hull
    end = clock();

    // Compute ellapsed time
    time_measure.push_back(double(end-start)/CLOCKS_PER_SEC*1000);
    std::cout << "Ellapsed time: " << time_measure.back() << "ms.\n\n";
  }

  // Compute statistics

  // Mean
  for(int s = 0; s < nb_samples; s++)
    mean += time_measure[s];

  mean /= nb_samples;

  // Standard deviation
  for(int s = 0; s < nb_samples; s++)
    std += (time_measure[s] - mean) * (time_measure[s] - mean);

  std /= nb_samples;
  std = sqrt(std);

  // Display statistics
  std::cout << "\nMean time for this test: " << mean
            << "ms, std: " << std << "ms\n\n";
}
