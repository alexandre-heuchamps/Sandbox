// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//


#include "nutil.h"
#include <cstdio>
#include "vtkdisplay.h"


int main(void)
{

  data_container data;

  npoint p1(0,0,0),p2(1,0,0),p3(1,1,0),p4(0,1,0),
  p5(0,0,1),p6(1,0,1),p7(1,1,1),p8(0,1,1);
  
  properties ptr=data.getproppoints();
  ptr.c=color(100,200,60);
  ptr.pointsize=15;
  data.setproppoints(ptr);
  data.add_point(p1);
  data.add_point(p2);
  data.add_point(p3);
  data.add_point(p4);
  ptr.c=color(255,0,255);
  ptr.pointsize=7;
  data.setproppoints(ptr);
  data.add_point(p5);
  data.add_point(p6);
  data.add_point(p7);
  data.add_point(p8);
  data.add_point(npoint(0.5,0.5,0.5));

  
  ptr=data.getproptriangles();
  ptr.c=color(255,0,0);
  ptr.edgeon=true;
  ptr.edgecolor=color(255,255,255);
  ptr.edgethickness=5;
  data.setproptriangles(ptr);
  
  triangle tr;
  tr.pts[0]= npoint3(0,0.5,0.5);
  tr.pts[1]= npoint3(0.5,0,0.5);
  tr.pts[2]= npoint3(0.5,0.5,0);
  data.add_triangle(tr);
  ptr.c=color(0,0,255);
  ptr.edgeon=false;
  data.setproptriangles(ptr);
  tr.pts[0]= npoint3(0,-0.5,-0.5);
  tr.pts[1]= npoint3(-0.5,0,-0.5);
  tr.pts[2]= npoint3(-0.5,-0.5,0);
  data.add_triangle(tr);
  
  line l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
  l1.pts[0]=p1;
  l1.pts[1]=p2;
  l2.pts[0]=p2;
  l2.pts[1]=p3;
  l3.pts[0]=p3;
  l3.pts[1]=p4;
  l4.pts[0]=p4;
  l4.pts[1]=p1;
  l5.pts[0]=p5;
  l5.pts[1]=p6;
  l6.pts[0]=p6;
  l6.pts[1]=p7;
  l7.pts[0]=p7;
  l7.pts[1]=p8;
  l8.pts[0]=p8;
  l8.pts[1]=p5;

  l9.pts[0]=p1;
  l9.pts[1]=p5;
  l10.pts[0]=p2;
  l10.pts[1]=p6;
  l11.pts[0]=p3;
  l11.pts[1]=p7;
  l12.pts[0]=p4;
  l12.pts[1]=p8;
  ptr=data.getproplines();
  ptr.c=color(0,125,0);
  ptr.thickness=5;
  data.setproplines(ptr);
  data.add_line(l1);
  data.add_line(l2);
  data.add_line(l3);
  data.add_line(l4);
  ptr.c=color(255,0,0);
  data.setproplines(ptr);
  data.add_line(l5);
  data.add_line(l6);
  ptr.thickness=10;
  data.setproplines(ptr);
  data.add_line(l7);
  data.add_line(l8);
  ptr.thickness=15;
  data.setproplines(ptr);
  data.add_line(l9);
  data.add_line(l10);
  ptr.thickness=2;
  data.setproplines(ptr);
  data.add_line(l11);
  data.add_line(l12);

  quad qu;
  qu.pts[0]=p1;
  qu.pts[1]=p6;
  qu.pts[2]=p7;
  qu.pts[3]=p4;
  ptr=data.getpropquads();
  ptr.c=color(0,255,0,128); // semi-transparent
  ptr.edgeon=false;
  data.setpropquads(ptr);
  data.add_quad(qu);
  qu.pts[0]=p1;
  qu.pts[1]=p2;
  qu.pts[2]=p3;
  qu.pts[3]=p4;
  ptr.c=color(100,100,100,255); 
  data.setpropquads(ptr);
  data.add_quad(qu);
  
  npoint p10(2,2,2);
  point pp;
  pp.pts=p10;
  char mess[255];
  sprintf(mess,"Hello");
  pp.info=mess;
  color cc=color(0,255,255);
  std::pair<point,color> tmp(pp,cc);
  data.add_text(0,tmp);

  
  
  
  vtkdisplay display(color(0,0,0),(char*)"Test VTK");
  display.init_data(data);
  display.display();

  return 0;
}


