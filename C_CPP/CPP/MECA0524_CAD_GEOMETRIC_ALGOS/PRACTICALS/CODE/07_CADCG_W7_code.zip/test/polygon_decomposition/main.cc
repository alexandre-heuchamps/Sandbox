// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdexcept>
#include <limits>
#include <list>

#include "nutil.h"
#include "ndisplay.h"

// The machine epsilon has to be scaled to the magnitude of the values used
// and multiplied by the desired precision in ULPs (units in the last place)
/// \brief Return true if x and y are "nearly" equal, false otherwise.
template<class T>
inline bool nearly_equal(const T &x, const T &y, const int ulp = 2)
{
  return std::abs(x-y) <= std::numeric_limits<T>::epsilon() * std::abs(x+y) * ulp
    // unless the result is subnormal
           || std::abs(x-y) < std::numeric_limits<T>::min();
}

enum VertexType
{
  UNKNOWN_V = -1,
  START = 0,
  END = 1,
  MERGE = 2,
  SPLIT = 3,
  REGULAR = 4
};

enum EdgeType
{
  UNKNOWN_E = -1,
  LEFT_LEFT = 0,
  RIGHT_RIGHT = 1,
  LEFT_RIGHT = 2,
  NORMAL = 3,
  DIAGONAL = 4
};

struct edge; // Forward declaration.

struct vertex
{
  vertex(const int id_ = -1): pt(npoint2()), p(NULL), n(NULL), type(UNKNOWN_V), id(id_) {}
  vertex(const npoint2 &pt_, const int id_ = -1): pt(pt_), p(NULL), n(NULL), type(UNKNOWN_V), id(id_) {}

  npoint2 pt;
  edge* p; // Previous.
  edge* n; // Next.
  VertexType type;
  int id;

  bool operator<(const vertex &rhs) const // Lexicographical order
  {
    const bool nearly_x_equal = nearly_equal(pt[0], rhs.pt[0]);
    if(!nearly_x_equal && (pt[0] < rhs.pt[0])) return true;
    if(!nearly_x_equal && (pt[0] > rhs.pt[0])) return false;
    if(pt[1] < rhs.pt[1]) return true;
    return false;
  }
};

struct edge
{
  edge(): s(NULL), e(NULL), corr(NULL), type(UNKNOWN_E) {}
  edge(vertex* se): s(se), e(se), corr(NULL), type(UNKNOWN_E) {}
  edge(vertex* s_, vertex* e_): s(s_), e(e_), corr(NULL), type(UNKNOWN_E) {}

  vertex* s; // Start vertex.
  vertex* e; // End vertex.
  vertex* corr; // Corresponding vertex.
  EdgeType type;
};

// Functor comparison for vertices.
class CompareVertex
{
public:
  bool operator()(const vertex* v1, const vertex* v2) const
  {
    return (*v1) < (*v2);
  }
};

double eval_point_on_edge(const edge *el, const double x)
{
  double m, b;

  m = (el->e->pt[1] - el->s->pt[1])/(el->e->pt[0] - el->s->pt[0]);
  b = el->s->pt[1] - m*(el->s->pt[0]);
  return (m*x + b);
}

// Dynamic comparison functor for edges.
class CompareEdge
{
public:
  bool operator()(const edge* e1, const edge* e2) const
  {
    // Test for identical edges.
    if(nearly_equal(e1->s->pt[0], e2->s->pt[0]) && nearly_equal(e1->s->pt[1], e2->s->pt[1]) &&
       nearly_equal(e1->e->pt[0], e2->e->pt[0]) && nearly_equal(e1->e->pt[1], e2->e->pt[1]))
      return false;

    // Tests for different edges.
    if (nearly_equal(e1->s->pt[0], e1->e->pt[0]) && nearly_equal(e2->s->pt[0], e2->e->pt[0]))
    {
        double y_e1_min, y_e2_max;

        y_e1_min = std::min(e1->s->pt[1], e1->e->pt[1]);// (e1->s->pt[1] + e1->e->pt[1]) / 2.0;
        y_e2_max = std::max(e2->s->pt[1], e2->e->pt[1]);// (e2->s->pt[1] + e2->e->pt[1]) / 2.0;

        if(nearly_equal(y_e1_min, y_e2_max))
        {
          // Compare the other two extremities of the edges.
          double y_e1_max = std::max(e1->s->pt[1], e1->e->pt[1]);
          double y_e2_min = std::min(e2->s->pt[1], e2->e->pt[2]);
          return (y_e1_max < y_e2_min);
        }
        else
          return (y_e1_min < y_e2_max);
    }
    else if (nearly_equal(e1->s->pt[0], e1->e->pt[0]))
    {
        double y_e1_min, y_e2;

        y_e1_min = std::min(e1->s->pt[1], e1->e->pt[1]);// (e1->s->pt[1] + e1->e->pt[1]) / 2.0;
        y_e2 = eval_point_on_edge(e2, x);

        if(nearly_equal(y_e1_min, y_e2))
        {
          double y_e1_max = std::max(e1->s->pt[1], e1->e->pt[1]);
          return (y_e1_max < y_e2);
        }
        else
          return (y_e1_min < y_e2);
    }
    else if (nearly_equal(e2->s->pt[0], e2->e->pt[0]))
    {
        double y_e2_min, y_e1;

        y_e2_min = std::min(e2->s->pt[1], e2->e->pt[1]); //(e2->s->pt[1] + e2->e->pt[1]) / 2.0;
        y_e1 = eval_point_on_edge(e1, x);

        if(nearly_equal(y_e1, y_e2_min))
        {
          double y_e2_max = std::max(e2->s->pt[1], e2->e->pt[0]);
          return (y_e1 < y_e2_max);
        }
        else
          return (y_e1 < y_e2_min);
    }
    else
    {
        double y_e1, y_e2;

        y_e1 = eval_point_on_edge(e1, x);
        y_e2 = eval_point_on_edge(e2, x);

        if(nearly_equal(y_e1, y_e2))
        {
          // Determine the maximum (signed) separation distance
          // between e1 and e2 in the intersection of their x-interval.
          double e1_x_max = std::max(e1->s->pt[0], e1->e->pt[0]);
          double e1_x_min = std::min(e1->s->pt[0], e1->e->pt[0]);
          double e2_x_max = std::max(e2->s->pt[0], e2->e->pt[0]);
          double e2_x_min = std::min(e2->s->pt[0], e2->e->pt[0]);

          double x_max = std::min(e1_x_max, e2_x_max);
          double x_min = std::max(e1_x_min, e2_x_min);

          double y_e1_min = eval_point_on_edge(e1, x_min);
          double y_e1_max = eval_point_on_edge(e1, x_max);
          double y_e2_min = eval_point_on_edge(e2, x_min);
          double y_e2_max = eval_point_on_edge(e2, x_max);

          double dist_y_min = y_e2_min - y_e1_min;
          double dist_y_max = y_e2_max - y_e1_max;

          if(abs(dist_y_min) > abs(dist_y_max))
            return (dist_y_min > 0);
          else
            return (dist_y_max > 0);
        }
        else
         return (y_e1 < y_e2);
    }
  }

  static double x;
};

double CompareEdge::x = 1;

// Declaration of prototypes
void fill_vertices(std::vector<vertex> &v);
void create_polygon(std::vector<edge> &polygon, std::vector<vertex> &v);
void show_polygon(data_container &data, const std::vector<edge> &polygon);
double compute_angle(const vertex &v);
EdgeType compute_edges_configuration(const vertex &v);
void tag_vertices(std::vector<edge> &v);
void make_monotone(std::vector<edge> &polygon_0, std::list<edge> &diagonals);

// main function
int main(int argc, char** argv)
{
  // Visualization
  std::vector<data_container> buffer(1);
  data_container &data=buffer[0];
  ndisplay display;                 // Display window

  std::vector<vertex> vertices;

  fill_vertices(vertices);

  std::vector<edge> polygon; // Polygon defined by line in an anti-clockwise fashion.
  create_polygon(polygon, vertices);
  show_polygon(data, polygon);

  std::list<edge> diagonals;
  make_monotone(polygon, diagonals);

  // Add diagonals with a different colour.
  data.setcolorlines(color(0, 255, 0));
  for(typename std::list<edge>::const_iterator it = diagonals.begin(); it != diagonals.end(); ++it)
  {
    const edge &l = *it;
    data.add_line(line(l.s->pt, l.e->pt));
  }

  display.init_data(buffer);
  display.display();

  return 0;
}

// Create vertices for the polygon
void fill_vertices(std::vector<vertex> &v)
{
  v.push_back(vertex(npoint2(0.1, 0.1), 0));
  v.push_back(vertex(npoint2(0.2, 0.05), 1));
  v.push_back(vertex(npoint2(0.3, 0.1), 2));
  v.push_back(vertex(npoint2(0.25, 0.15), 3));
  v.push_back(vertex(npoint2(0.4, 0.2), 4));
  v.push_back(vertex(npoint2(0.5, 0.1), 5));
  v.push_back(vertex(npoint2(0.6, 0.2), 6));
  v.push_back(vertex(npoint2(0.55, 0.5), 7));
  v.push_back(vertex(npoint2(0.5, 0.4), 8));
  v.push_back(vertex(npoint2(0.47, 0.3), 9));
  v.push_back(vertex(npoint2(0.35, 0.25), 10));
  v.push_back(vertex(npoint2(0.15, 0.3), 11));
  v.push_back(vertex(npoint2(0.35, 0.35), 12));
  v.push_back(vertex(npoint2(0.3, 0.5), 13));
  v.push_back(vertex(npoint2(0.05, 0.35), 14));
  v.push_back(vertex(npoint2(0.1, 0.2), 15));
  v.push_back(vertex(npoint2(0.3, 0.225), 16));
}

// Create a polygon with lines in an anti-clokwise fashion.
void create_polygon(std::vector<edge> &polygon, std::vector<vertex> &v)
{
  polygon.clear();

  for (int i=0; i<v.size()-1; i++)
    polygon.push_back(edge(&v[i], &v[i+1]));

  polygon.push_back(edge(&v[v.size()-1], &v[0]));

  for (int j=1; j<v.size(); j++)
  {
    v[j].p = &polygon[j-1];
    v[j].n = &polygon[j];
  }
  v[0].p = &polygon[polygon.size()-1];
  v[0].n = &polygon[0];
}

// Show a polygon on the screen.
void show_polygon(data_container &data, const std::vector<edge> &polygon)
{
  properties ptr = data.getproppoints();
  ptr.pointsize = 3;
  data.setproppoints(ptr);


  for(size_t i = 0; i < polygon.size(); i++)
  {
    const edge &l = polygon[i];
    data.add_point(l.s->pt);
    data.add_point(l.e->pt);
    data.add_line(line(l.s->pt, l.e->pt));
  }
}

// Compute the angle between the two edges pointed by vertex v
double compute_angle(const vertex &v)
{
  npoint2 vec1 = v.p->s->pt - v.pt;
  npoint2 vec2 = v.n->e->pt - v.pt;

  vec1.normalize();
  vec2.normalize();

  double alpha = atan2(crossprod(vec1, vec2), vec1*vec2);
  if(alpha > M_PI) alpha -= 2*M_PI;
  if(alpha <= -M_PI) alpha += 2*M_PI;

  return alpha;
}

// Tells how the two edges pointed by vertex v
// are situated w.r.t a vertical line through v
EdgeType compute_edges_configuration(const vertex &v)
{
  if( (*(v.p->s) < v) && (*(v.n->e) < v) )
    return LEFT_LEFT;

  if( (v < *(v.p->s)) && (v < *(v.n->e)))
    return RIGHT_RIGHT;

  return LEFT_RIGHT;
}

// Tag the vertices following their type.
void tag_vertices(std::vector<edge> &poly)
{
  double alpha;
  EdgeType configuration;

  for(size_t i = 0; i < poly.size(); ++i)
  {
    vertex &v = *(poly[i].s);
    alpha = compute_angle(v);
    configuration = compute_edges_configuration(v);

    if(configuration == RIGHT_RIGHT)
    {
      if(alpha <= 0.0)
        v.type = START;
      else
        v.type = SPLIT;
    }
    else if(configuration == LEFT_LEFT)
    {
      if(alpha <= 0.0)
        v.type = END;
      else
        v.type = MERGE;
    }
    else
      v.type = REGULAR;
  }
}

// Update the status T for a start vertex
void handle_start_vertex(vertex &v, std::set<edge*, CompareEdge> &T, std::list<edge> &polygon)
{
    CompareEdge::x = v.pt[0];
    T.insert(v.n);
    v.n->corr = &v;
}

// Update the status T for an end vertex
void handle_end_vertex(vertex &v, std::set<edge *, CompareEdge> &T, std::list<edge> &polygon)
{
    CompareEdge::x = v.pt[0];

    if (v.p->corr->type == MERGE)
        polygon.push_back(edge(&v, v.p->corr));
    T.erase(v.p);
}

// Update the status T for a split vertex
void handle_split_vertex(vertex &v, std::set<edge *, CompareEdge> &T, std::list<edge> &polygon)
{
    CompareEdge::x = v.pt[0];

    edge* ed = new edge(&v);
    typename std::set<edge*, CompareEdge>::iterator it = std::lower_bound(T.begin(), T.end(), ed, CompareEdge());
    edge* lower_edge=NULL;
    lower_edge = *(--it);

    polygon.push_back(edge(&v, lower_edge->corr));

    lower_edge->corr = &v;

    T.insert(v.n);

    v.n->corr = &v;

    delete ed;
}

// Update the status T for a merge (fuse) vertex
void handle_merge_vertex(vertex &v, std::set<edge*, CompareEdge> &T, std::list<edge> &polygon)
{
    CompareEdge::x = v.pt[0];

    if (v.p->corr->type == MERGE)
        polygon.push_back(edge(&v, v.p->corr));

    T.erase(v.p);

    edge* ed = new edge(&v);
    typename std::set<edge*, CompareEdge>::iterator it = std::lower_bound(T.begin(), T.end(), ed, CompareEdge());
    edge* lower_edge=NULL;
    lower_edge = *(--it);

    if (lower_edge->corr->type == MERGE)
        polygon.push_back(edge(&v, lower_edge->corr));

    lower_edge->corr = &v;

    delete ed;
}

// Update the status T for a regular vertex
void handle_regular_vertex(vertex &v, std::set<edge*, CompareEdge> &T, std::list<edge> &polygon)
{
    CompareEdge::x = v.pt[0];

    if(v < *(v.n->e)) // i.e. The polygon is above the vertex
    {

    }
    else
    {

    }
}

// General function adding diagonal to a polygon
// in order to get monotone polygons w.r.t to the x coordinate
void make_monotone(std::vector<edge> &polygon_0, std::list<edge> &diagonals)
{
    tag_vertices(polygon_0);

    std::vector<vertex*> vertices;
    for (typename std::vector<edge>::const_iterator it=polygon_0.begin(); it!=polygon_0.end(); ++it)
    {
        edge ed=*it;
        vertices.push_back(const_cast<vertex*>(ed.e));
    }

    std::sort(vertices.begin(), vertices.end(), CompareVertex());
    std::set<edge*, CompareEdge> T;

    for (size_t i=0; i<vertices.size(); i++)
    {
        switch(vertices[i]->type)
        {
            case START:
                handle_start_vertex(*vertices[i], T, diagonals);
                break;
            case END:
                handle_end_vertex(*vertices[i], T, diagonals);
                break;
            case MERGE:
                handle_merge_vertex(*vertices[i], T, diagonals);
                break;
            case SPLIT:
                handle_split_vertex(*vertices[i], T, diagonals);
                break;
            case REGULAR:
                handle_regular_vertex(*vertices[i], T, diagonals);
                break;
            default:
                throw std::runtime_error("Unknown vertex tag!");

        }
    }
}
