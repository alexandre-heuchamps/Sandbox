// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <fstream>
#include "nlagrange.h"
#include "nspline.h"
#include "nbspline.h"
#include "nbeziercurve.h"

#include "ndisplay.h"
#include "nutil.h"
#include "gnurbscallbacks.h"

// Initialization function prototype
// the complete implementation can be found at the end of the file
// DX and DY are the offsets with respect to the origin
void init_bspline(nbspline &curve,double DX,double DY);
void init_bspline_nonuniform(nbspline &curve,double DX,double DY);
void init_bspline_periodic(nbspline &curve,double DX,double DY);

// main function

int main(void)
{
  data_container data;                // Contains data to display
  ndisplay display;                   // Display window
  int nCP=10;                         // Number of control points
  nbspline curve(nCP,3);              // BSpline curve with nCP control points
  nbspline curvep1(nCP,3);
  nbspline curvep2(nCP,3);

  init_bspline(curve,-1.5,-4.5);      // Curves initialization
  init_bspline_nonuniform(curvep1, 1.5, -4.5);
  init_bspline_periodic(curvep2, 4, -4.5);

  properties prop0, prop1, prop2;
  prop0.pointsize = 5.0f;
  prop1.pointsize = 5.0f;
  prop2.pointsize = 5.0f;
  prop1.c = color(255, 0, 0);
  prop2.c = color(0, 255, 0);

  gnurbscallbacks CB;
  CB.add_entity(&curve, prop0);
  CB.add_entity(&curvep1, prop1);
  CB.add_entity(&curvep2, prop2);

  display.setcallbacks(&CB);
  CB.draw();
  display.init_data(CB.datas);        // Transfer of the data to display
  display.display();                  // Display loop
  return 0;
}

void init_bspline(nbspline &curve,double DX,double DY)
{
  for (int i=0;i< curve.nb_CP();i++)
  {
    double angle=i*n_pi/(curve.nb_CP()-1);
    npoint val;
    val[0]=cos(angle)+DX;
    val[1]=sin(angle)+DY;
    val[2]=0;
    val[3]=1;
    curve.CP(i)=val;
  }

  int ends=curve.degree()+1;
  int i;
  for (i=1;i<=(curve.nb_CP()+1+curve.degree()-2*ends);++i)
  {
    curve.u(i+ends-1)=i;
  }
  for (int j=0;j<ends;++j)
  {
    curve.u(j)=0.0;
    curve.u(curve.nb_CP()+curve.degree()-j)=i;
  }
}

void init_bspline_nonuniform(nbspline &curve,double DX,double DY)
{
  // Implement a periodic curve with a non-uniform nodal sequence
  // with interpolating first and last control point.
}

void init_bspline_periodic(nbspline &curve,double DX,double DY)
{
  // Implement a periodic curve with a periodic nodal sequence.
  // You have to locate the control points in an adequate way.
}
