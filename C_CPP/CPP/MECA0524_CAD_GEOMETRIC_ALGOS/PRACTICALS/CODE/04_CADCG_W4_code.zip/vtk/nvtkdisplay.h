// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NVTKDISPLAY_H
#define __NVTKDISPLAY_H

#include <vector>

#include <vtkSmartPointer.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkContourWidget.h>

#include "ncurve.h"
#include "nvtkCurveRep.h"
#include "vtkdisplay.h"

/// Display class.
class nvtkdisplay : public vtkdisplay
{

public:
  /// \brief Constructor with window color & name
  nvtkdisplay(color c=color(25, 51, 102,255),char *nom=NULL) : vtkdisplay(c,nom) {}

  /// \brief Adds a curve to display. Allows interactive modification of the curve
  /// by moving its control points.
  /// \param[in] curve curve to display.
  /// \param[in] cp color of the control points.
  /// \param[in] cl color of the lines discretizing the curve.
  virtual void add_curve(ncurve* curve, color cp = color(), color cl=color());
private :
  std::vector<ncurve *> curves;
  std::vector<nvtkCurveRep *> vtkcurves;
  std::vector<vtkContourWidget *> vtkcurvewidgets;
};


#endif// __VTKDISPLAY_H
