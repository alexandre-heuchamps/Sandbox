// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __KEYBOARDCALLBACK_H
#define __KEYBOARDCALLBACK_H

#include "vtkCommand.h"
#include "vtkdisplay.h"

class keyboardCallback : public vtkCommand
{
private:
  vtkdisplay* myDisplay;
  keyboardCallback(vtkdisplay * diplay) :vtkCommand()
  {
    myDisplay=diplay;
  }
public:
  static keyboardCallback* New(vtkdisplay * display)
  {
    return new keyboardCallback(display);
  }
  void Delete()
  {
    delete this;
  }
  virtual void Execute(vtkObject *caller, unsigned long, void*);
};

#endif
