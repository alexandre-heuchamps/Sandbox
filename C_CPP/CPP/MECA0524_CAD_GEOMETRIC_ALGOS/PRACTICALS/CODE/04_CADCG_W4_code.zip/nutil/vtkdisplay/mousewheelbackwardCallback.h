// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __MOUSEWHEELBACKWARDCALLBACK_H
#define __MOUSEWHEELBACKWARDCALLBACK_H

#include "vtkCommand.h"
#include "vtkdisplay.h"

class mousewheelbackwardCallback : public vtkCommand
{
private:
  vtkdisplay* myDisplay;
  mousewheelbackwardCallback(vtkdisplay * diplay) :vtkCommand()
  {
    myDisplay=diplay;
  }
public:
  static mousewheelbackwardCallback* New(vtkdisplay * display)
  {
    return new mousewheelbackwardCallback(display);
  }
  void Delete()
  {
    delete this;
  }
  virtual void Execute(vtkObject *caller, unsigned long, void*);
};

#endif
