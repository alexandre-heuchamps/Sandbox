//
// C++ Interface: nbspline
//
// Description:
//
//
// Authors: Eric Bechet <eric.bechet@ulg.ac.be> (C) 2012
//          Etienne Lemaire
//          Frederic Duboeuf
//
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef __NBSPLINE_H
#define __NBSPLINE_H


#include "ncurve.h"
#include <vector>
#include <list>

class nbspline : public nparametriccurve
{
protected:
  std::vector<npoint> val; // control points
  int nCP; // number of control points
  std::vector<double> knots; // nodal sequence
  int nknots; // number of knots
  int deg;
public:
  nbspline() : nCP(1),nknots(2),deg(0),knots(2),val(1)
  {
    knots[0]=0;
    knots[1]=1;
    val[0]=npoint();
  }
  nbspline(int nCP_,int degree_) : val(nCP_),nCP(nCP_),deg(degree_),nknots(nCP_+degree_+1),knots(nCP_+degree_+1) {}
  void reset(int nCP_,int degree_)
  {
    val.resize(nCP_);
    nCP=nCP_,deg=degree_,nknots= (nCP_+degree_+1);
    knots.resize(nCP_+degree_+1);
  }
  virtual int degree(void) const
  {
    return deg ;
  }
  virtual int nb_CP(void) const
  {
    return nCP ;
  }
  virtual int nb_knots(void) const
  {
    return nknots ;
  }
  virtual double min_u(void) const
  {
    return knots[deg];
  }
  virtual double max_u(void) const
  {
    return knots[nknots-deg-1];
  }
  virtual void P(double u_,npoint& ret) const ;    // position of a point on the curve
  virtual npoint CP(int which) const
  {
    return val[which];
  }
  virtual npoint& CP(int which)
  {
    return val[which];
  }
  virtual void set_CP(int which,const npoint& pt)
  {
    val[which]=pt;
  } ;
  virtual double u(int which) const
  {
    return knots[which];
  }
  virtual double& u(int which)
  {
    return knots[which];
  }
  void translate(const npoint &ret);
  virtual nbspline* clone() const
  {
    return new nbspline(*this);
  }
  // Given a parameter u, returns an indice k such that u belongs to [u_k, u_k+1[
  // where the u_k are the knots.
  //
  // knots [input]:	list of knots.
  // nknots [input]:	number of knots.
  // deg [input]:	wanted degree of the shape functions.
  // u [input]:		curve parameter.
  int findspan(const std::vector<double> &knots,int nknots,int deg,double u) const;
};

#endif // __NBSPLINE_H

