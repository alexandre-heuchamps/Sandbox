// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nlagrange.h"
#include <cmath>

void nlagrange::P(double u_, npoint& ret) const
{
  ret = npoint(0.0, 0.0, 0.0, 0.0);

  for(int i = 0; i < nCP; i++)
    ret += Basis(i, u_)*val[i];
}

double nlagrange::Basis(int which,double u_) const
{
  double ret = 1.0;

  for(int j = 0; j < which; j++)
    ret *= (u_ - pos[j]) / (pos[which] - pos[j]);

  for(int j = which+1; j < (int)pos.size(); j++)
   ret *= (u_ - pos[j]) / (pos[which] - pos[j]);

  return ret;
}

void nlagrange::translate(npoint vec)
{
  for (int i=0;i<nCP;++i) val[i]+=vec;
}
