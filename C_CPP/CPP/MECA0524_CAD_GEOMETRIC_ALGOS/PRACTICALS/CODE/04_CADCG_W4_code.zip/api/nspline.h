//
// C++ Interface: nspline
//
// Description:
//
//
// Authors: Eric Bechet <eric.bechet@ulg.ac.be> (C) 2012
//          Etienne Lemaire
//          Frederic Duboeuf
//
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef __NSPLINE_H
#define __NSPLINE_H


#include "nlagrange.h"
#include <vector>

class nspline : public nlagrange
{
protected:
  std::vector<npoint> der;
  double card;
  enum {TypeUnknown,FiniteDifferences,Cardinal,Natural} type; 
    // type of spline (defines the way derivatives are computed )
public:
  nspline(int nCP_) : nlagrange(nCP_),der(nCP_),type(TypeUnknown),card(0) {}
  void compute_FD(void);
  void compute_cardinal(double c);
  void compute_natural(void);
  virtual int degree(void) const
  {
    return 3 ;
  }
  virtual void P(double u_,npoint& ret) const ;    // position along the curve
  virtual void set_CP(int which,const npoint& pt)  // sets a control point
  {
    val[which]=pt;
    update();
  }
  virtual void update(); // recomputes derivatives from point positions
  virtual nspline* clone() const
  {
    return new nspline(*this);
  }
private :
  void tridiagsolve(std::vector<double>& rhs);
};


#endif // __NSPLINE_H
