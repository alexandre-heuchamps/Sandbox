//
// C++ Interface: nbeziercurve
//
// Description:
//
//
// Authors: Eric Bechet <eric.bechet@ulg.ac.be> (C) 2012
//          Etienne Lemaire
//          Frederic Duboeuf
//
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef __NBEZIERCURVE_H
#define __NBEZIERCURVE_H


#include "ncurve.h"
#include <vector>
#include <iostream>
#include <list>

class nbeziercurve : public nparametriccurve
{
  std::vector<npoint> val; // array of control points
  int nCP; // number of control points
public:
  nbeziercurve(int nCP_) : val(nCP_),nCP(nCP_) {}
  virtual int degree(void) const // returns the polynomial degree
  {
    return nCP-1 ;
  }
  virtual int nb_CP(void) const // returns the number of contro points
  {
    return nCP ;
  }
  virtual void add_CP(const npoint &val_) // adds a control point at the end of the array
  {
    val.push_back(val_);
    nCP++;
  }
  virtual double min_u(void) const // returns the minimal possible for the parameter u
  {
    return 0.;
  }
  virtual double max_u(void) const // returns the maxima possible value for the parameter u
  {
    return 1.;
  }
  double Basis(int which,double u) const;    // basis functions
  virtual void P(double u_,npoint& ret) const ; // computes the coordinates of a point along the curve
  virtual npoint CP(int which) const
  {
    return val[which];  // returns one of the control points (numbering starts at 0) (constant)
  }
  virtual npoint& CP(int which)
  {
    return val[which];  // returns one of the control points (numbering starts at 0)
  }
  virtual void set_CP(int which,const npoint& pt)  // sets a control point to a specified position
  {
    val[which]=pt;
  }
  virtual void set_nb_CP(int nb)  // sets the number of control points
  {
    val.resize(nb);
    nCP=nb;
  }
  void degree_elevation(); // increases the degree of the curve by 1 (curve remains geometrically unchanged)
  void translate(npoint vec); // translates the curve by vector vec

  virtual nbeziercurve* clone() const // returns a clone of the curve (allocated on the heap)
  {
    return new nbeziercurve(*this);
  }
private:
  void DeCasteljau(double u_, npoint & ret) const ;
  void DeCasteljau(double u_, npoint & ret,nbeziercurve &left,nbeziercurve &right) const ;
  void DeCasteljau(double u_, int stop,std::vector<npoint>& ret) const ;
};

#endif // __NBEZIERCURVE_H

