//
// C++ Implementation: nbspline
//
// Description:
//
//
// Authors: Eric Bechet <eric.bechet@ulg.ac.be> (C) 2012
//          Etienne Lemaire
//          Frederic Duboeuf
//
//
// Copyright: See COPYING file that comes with this distribution
//
//

#include "nbspline.h"

#include <cmath>
#include <iostream>
#include <limits>

void nbspline::P(double u_, npoint& ret) const
{
  // Computes i such that u_ \in [u_i, u_{i+1}[
  const int i = findspan(knots, nknots, deg, u_);
  
  //Insert your code here...
}

void nbspline::translate(const npoint &ret)
{
  for(int i = 0; i < nCP; ++i) val[i] += ret;
}

int nbspline::findspan(const std::vector<double> &knots,int nknots,int deg,double u) const
{
  int inter;
  int nCP=nknots-deg-1;
  if (u>=knots[nCP]) return nCP-1;
  if (u<=knots[deg]) return deg;

  int low=deg,high=nCP+1;
  int mid= (low+high) /2;
  while ((u<knots[mid]) || (u>= knots[mid+1]))
  {
    if (u<knots[mid]) high=mid;
    else low=mid;

    mid= (low+high)/2;
  }

  return mid;
}
