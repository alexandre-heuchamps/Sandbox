// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NUTIL_H
#define __NUTIL_H

#include <vector>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>

#include "linear_algebra.h"
#include "npoint.h"
#include "ndata.h"
#include "ndisplay_base.h"
#include "nutilconfig.h"

double randr(void);

#endif //__NUTIL_H
