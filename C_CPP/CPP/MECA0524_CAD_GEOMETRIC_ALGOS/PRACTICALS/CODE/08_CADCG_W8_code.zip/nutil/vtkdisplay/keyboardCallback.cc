// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "keyboardCallback.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkRenderWindow.h"

void
keyboardCallback::Execute(vtkObject *caller, unsigned long, void*)
{
  vtkRenderWindowInteractor *interactor = reinterpret_cast<vtkRenderWindowInteractor*>(caller);
  int key=interactor->GetKeyCode();
  //std::cerr<<"keyboardCallBack::Execute : called "<<key<<std::endl;

  myDisplay->kbCallback(key);
}
