// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "mousewheelforwardCallback.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkRenderWindow.h"

void mousewheelforwardCallback::Execute(vtkObject *caller, unsigned long, void*)
{
  vtkRenderWindowInteractor *interactor = reinterpret_cast<vtkRenderWindowInteractor*>(caller);
  int x,y;
  interactor->GetMousePosition(&x,&y);
  
  myDisplay->mousewheelforwardCall(x,y);
}
