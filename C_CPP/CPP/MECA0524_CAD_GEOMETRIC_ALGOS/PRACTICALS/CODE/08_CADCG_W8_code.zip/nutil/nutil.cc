// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nutil.h"
#include <cstdlib>
double randr(void)
{
  return rand() /double(RAND_MAX);
}



