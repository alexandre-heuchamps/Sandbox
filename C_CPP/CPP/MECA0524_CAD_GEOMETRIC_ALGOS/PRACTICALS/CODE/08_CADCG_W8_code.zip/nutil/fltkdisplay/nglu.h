// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __NGLU_H
#define __NGLU_H

#include <FL/gl.h>

// old utility functions to compute transformation matrices

void _gluMultMatricesd ( const GLdouble a[16], const GLdouble b[16],GLdouble r[16] );
void _gluMultMatrixVecd ( const GLdouble matrix[16], const GLdouble in[4],GLdouble out[4] );
int _gluInvertMatrixd ( const GLdouble src[16], GLdouble inverse[16] );
void _gluMakeIdentityd ( GLdouble m[16] );
void _gluPerspective ( GLdouble fovyInDegrees, GLdouble aspectRatio,
                           GLdouble znear, GLdouble zfar );
void _gluLookAt ( GLdouble *eyePosition3D,
                      GLdouble *center3D, GLdouble *upVector3D );
int _gluUnProjectFast ( GLdouble winx, GLdouble winy, GLdouble winz,
                            const GLdouble Inv[16],
                            const GLint viewport[4],
                            GLdouble *objx, GLdouble *objy, GLdouble *objz );
int _gluProjectFast (GLdouble objx, GLdouble objy, GLdouble objz,
                            const GLdouble Mat[16],
                            const GLint viewport[4],
                            GLdouble *winx, GLdouble *winy, GLdouble *winz);


#endif //__NGLU_H