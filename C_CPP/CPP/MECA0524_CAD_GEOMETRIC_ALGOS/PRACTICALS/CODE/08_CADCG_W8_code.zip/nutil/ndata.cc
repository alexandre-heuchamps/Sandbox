// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "ndata.h"

int my_stricmp ( const char *s1, const char*s2 )
{
  int c1, c2;
  int cmp = 0;

  if (s1 && s2)
  for (;;)
  {
    c1 = *s1++;
    c2 = *s2++;
    if (c1 && c2)
    {
      c1 = tolower(c1)&0xFF; // 8 bits
      c2 = tolower(c2)&0xFF; // only
      if (c1 < c2)
      {
        cmp = -1;
        break;
      }
      else if (c1 > c2)
      {
        cmp = 1;
        break;
      }
    }
    else
    {
      if (c1)
      cmp = 1;
      else if (c2)
      cmp = -1;
      break;
    }
  }
  return cmp;
}

std::ostream& operator<<(std::ostream& stream, 
                     const data_container& data)
{
  data.print(stream);
  return stream;
}

int data_container::read(std::istream& stream)
{
  std::string buf;
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"points")==0) // ok
  {
    int npts;
    stream >> npts;
//    std::cout << "points " << npts << std::endl;
    points.resize(npts);
    for(int i=0;i<npts;++i)
    {
      point p;
      int szbuf;
      stream >> p.pts[0] >> p.pts[1] >> p.pts[2] >> szbuf;
      if (szbuf)
      {
        char str[szbuf+1];str[szbuf]=0x0;
        stream.read(str,1);
        stream.get(str,szbuf+1);
        std::string s(str);
        p.info=s;
      }
//      std::cout << p.pts << " " << p.info << std::endl;
      points[i]=p;
    }
  }
  else 
   return -1; 
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"proppoints")==0) // ok
  {
    int npts;
    stream >> npts;
//    std::cout << "proppoints " << npts << std::endl;
    proppoints.resize(npts);
    for(int i=0;i<npts;++i)
    {
      int R,G,B,A,Re,Ge,Be,Ae,edgeon,teston;
      double thickness,edgethickness,pointsize;
      std::pair<properties,int> pp;
      stream >> buf >> pp.second >> R >> G >> B >> A >> pp.first.thickness >> pp.first.pointsize >> edgeon>> pp.first.edgethickness>> Re >> Ge >> Be >> Ae >> teston >> pp.first.nb_uid ;
      for (int ii=0;ii<pp.first.nb_uid;++ii) stream >> pp.first.uids[ii];
      pp.first.c=color(R,G,B,A);
      pp.first.edgecolor=color(Re,Ge,Be,Ae);
      pp.first.edgeon=edgeon;
      pp.first.teston=teston;
//      std::cout << "from " << pp.second << std::endl;
      proppoints[i]=pp;
    }
  }
  else 
   return -1; 

  stream >> buf ;
  if (my_stricmp(buf.c_str(),"lines")==0) // ok
  {
    int nl;
    stream >> nl;
//    std::cout << "lines " << nl << std::endl;
    lines.resize(nl);
    for(int i=0;i<nl;++i)
    {
      line l;
      int szbuf;
      stream >> l.pts[0][0] >> l.pts[0][1] >> l.pts[0][2] >> l.pts[1][0] >> l.pts[1][1] >> l.pts[1][2] >> szbuf;
      if (szbuf)
      {
        char str[szbuf+1];str[szbuf]=0x0;
        stream.read(str,1);
        stream.get(str,szbuf+1);
        std::string s(str);
        l.info=s;
      }
//      std::cout << l.pts[0] << " " << l.pts[1] << " " << l.info << std::endl;
      lines[i]=l;
    }
  }
  else 
   return -1; 
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"proplines")==0) // ok
  {
    int npts;
    stream >> npts;
//    std::cout << "proplines " << npts << std::endl;
    proplines.resize(npts);
    for(int i=0;i<npts;++i)
    {
      int R,G,B,A,Re,Ge,Be,Ae,edgeon,teston;
      double thickness,edgethickness,pointsize;
      std::pair<properties,int> pp;
      stream >> buf >> pp.second >> R >> G >> B >> A >> pp.first.thickness >> pp.first.pointsize >> edgeon>> pp.first.edgethickness>> Re >> Ge >> Be >> Ae >> teston >> pp.first.nb_uid ;
      for (int ii=0;ii<pp.first.nb_uid;++ii) stream >> pp.first.uids[ii];
      pp.first.c=color(R,G,B,A);
      pp.first.edgecolor=color(Re,Ge,Be,Ae);
      pp.first.edgeon=edgeon;
      pp.first.teston=teston;
//      std::cout << "from " << pp.second << std::endl;
      proplines[i]=pp;
    }
  }
  else
   return -1;
  
  
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"triangles")==0) // ok
  {
    int nt;
    stream >> nt;
//    std::cout << "triangles " << nt << std::endl;
    triangles.resize(nt);
    for(int i=0;i<nt;++i)
    {
      triangle t;
      int szbuf;
      stream >> t.pts[0][0] >> t.pts[0][1] >> t.pts[0][2] >> t.pts[1][0] >> t.pts[1][1] >> t.pts[1][2] >>  t.pts[2][0] >> t.pts[2][1] >> t.pts[2][2] >>szbuf;
      if (szbuf)
      {
        char str[szbuf+1];str[szbuf]=0x0;
        stream.read(str,1);
        stream.get(str,szbuf+1);
        std::string s(str);
        t.info=s;
      }
//      std::cout << t.pts[0] << " " << t.pts[1] << " " << t.pts[2] << " " << t.info << std::endl;
      triangles[i]=t;
    }
  }
  else 
   return -1; 
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"proptriangles")==0) // ok
  {
    int npts;
    stream >> npts;
//    std::cout << "proptriangles " << npts << std::endl;
    proptriangles.resize(npts);
    for(int i=0;i<npts;++i)
    {
      int R,G,B,A,Re,Ge,Be,Ae,edgeon,teston;
      double thickness,edgethickness,pointsize;
      std::pair<properties,int> pp;
      stream >> buf >> pp.second >> R >> G >> B >> A >> pp.first.thickness >> pp.first.pointsize >> edgeon>> pp.first.edgethickness>> Re >> Ge >> Be >> Ae >> teston >> pp.first.nb_uid ;
      for (int ii=0;ii<pp.first.nb_uid;++ii) stream >> pp.first.uids[ii];
      pp.first.c=color(R,G,B,A);
      pp.first.edgecolor=color(Re,Ge,Be,Ae);
      pp.first.edgeon=edgeon;
      pp.first.teston=teston;
//      std::cout << "from " << pp.second << std::endl;
      proptriangles[i]=pp;
    }
  }
  else 
   return -1; 
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"quads")==0) // ok
  {
    int nt;
    stream >> nt;
//    std::cout << "quads " << nt << std::endl;
    quads.resize(nt);
    for(int i=0;i<nt;++i)
    {
      quad t;
      int szbuf;
      stream >> t.pts[0][0] >> t.pts[0][1] >> t.pts[0][2] >> t.pts[1][0] >> t.pts[1][1] >> t.pts[1][2] >>  t.pts[2][0] >> t.pts[2][1] >> t.pts[2][2] >>  t.pts[3][0] >> t.pts[3][1] >> t.pts[3][2] >>szbuf;
      if (szbuf)
      {
        char str[szbuf+1];str[szbuf]=0x0;
        stream.read(str,1);
        stream.get(str,szbuf+1);
        std::string s(str);
        t.info=s;
      }
//      std::cout << t.pts[0] << " " << t.pts[1] << " " << t.pts[2] << " " << t.pts[3] << " " << t.info << std::endl;
      quads[i]=t;
    }
  }
  else 
   return -1; 
  stream >> buf ;
  if (my_stricmp(buf.c_str(),"propquads")==0) // ok
  {
    int npts;
    stream >> npts;
//    std::cout << "propquads " << npts << std::endl;
    propquads.resize(npts);
    for(int i=0;i<npts;++i)
    {
      int R,G,B,A,Re,Ge,Be,Ae,edgeon,teston;
      double thickness,edgethickness,pointsize;
      std::pair<properties,int> pp;
      stream >> buf >> pp.second >> R >> G >> B >> A >> pp.first.thickness >> pp.first.pointsize >> edgeon>> pp.first.edgethickness>> Re >> Ge >> Be >> Ae >> teston >> pp.first.nb_uid ;
      for (int ii=0;ii<pp.first.nb_uid;++ii) stream >> pp.first.uids[ii];
      pp.first.c=color(R,G,B,A);
      pp.first.edgecolor=color(Re,Ge,Be,Ae);
      pp.first.edgeon=edgeon;
      pp.first.teston=teston;
//      std::cout << "from " << pp.second << std::endl;
      propquads[i]=pp;
    }
  }
  else 
   return -1;
  for(int i=0;i<3;++i)
  {
    int n,nb;
    stream >> buf >> n >> nb;
//    std::cout << "texts " << n << " " << nb << std::endl;
    if ((my_stricmp(buf.c_str(),"texts")==0)&&(n==i)) // ok
    {
      texts[i].resize(nb);
      for(int p=0;p< nb;++p)
      {
        point pt;int R,G,B,A,szbuf;
        stream >>  pt.pts[0] >> pt.pts[1] >> pt.pts[2]  >> R >> G >> B >> A >> szbuf;
        if (szbuf)
        {
          char str[szbuf+1];str[szbuf]=0x0;
          stream.read(str,1);
          stream.get(str,szbuf+1);
          std::string s(str);
          pt.info=s;
        }
//        std::cout << pt.pts << " " << pt.info << std::endl;
        texts[i][p]=std::pair<point,color>(pt,color(R,G,B,A));
      }
    }
    else return -1;
  }
  return 0;
}


void data_container::unhide() const
{
  for(int p=0;p< points.size();++p)
  {
    points[p].drawable=true;
  }
  for(int p=0;p< lines.size();++p)
  {
    lines[p].drawable=true;
  }
  for(int p=0;p< triangles.size();++p)
  {
    triangles[p].drawable=true;
  }
  for(int p=0;p< quads.size();++p)
  {
    quads[p].drawable=true;
  }

  
}


void data_container::print(std::ostream& stream) const
{
  stream << "points " << points.size() << std::endl;
  for(int p=0;p< points.size();++p)
  {
    stream << points[p].pts << " " << points[p].info.length() << " " << points[p].info << std::endl;
  }
  stream << "proppoints " << proppoints.size() << std::endl;
  for(int p=0;p< proppoints.size();++p)
  {
    stream << "from " << proppoints[p].second << std::endl;
    properties pr=proppoints[p].first;
    stream << (int)pr.c.R  << " " << (int)pr.c.G << " " <<(int) pr.c.B << " " << (int)pr.c.A << " " ;
    stream << pr.thickness << " " << pr.pointsize << " " << pr.edgeon << " " << pr.edgethickness << " ";
    stream << (int)pr.edgecolor.R << " " <<(int)pr.edgecolor.G << " " <<(int)pr.edgecolor.B << " " <<(int)pr.edgecolor.A << " ";
    stream << pr.teston << " " << pr.nb_uid << " ";
    for (int i=0;i<pr.nb_uid;++i) stream << pr.uids[i] << " "; 
    stream << std::endl;
  }

  stream << "lines " << lines.size() << std::endl;
  for(int p=0;p< lines.size();++p)
  {
    stream << lines[p].pts[0] << " " << lines[p].pts[1]<< " " << lines[p].info.length() << " " << lines[p].info << std::endl;
  }
  stream << "proplines " << proplines.size() << std::endl;
  for(int p=0;p< proplines.size();++p)
  {
    stream << "from " << proplines[p].second << std::endl;
    properties pr=proplines[p].first;
    stream << (int)pr.c.R  << " " << (int)pr.c.G << " " <<(int) pr.c.B << " " << (int)pr.c.A << " " ;
    stream << pr.thickness << " " << pr.pointsize << " " << pr.edgeon << " " << pr.edgethickness << " ";
    stream << (int)pr.edgecolor.R << " " <<(int)pr.edgecolor.G << " " <<(int)pr.edgecolor.B << " " <<(int)pr.edgecolor.A << " ";
    stream << pr.teston << " " << pr.nb_uid << " ";
    for (int i=0;i<pr.nb_uid;++i) stream << pr.uids[i] << " "; 
    stream << std::endl;
  }
  
  stream << "triangles " << triangles.size() << std::endl;
  for(int p=0;p< triangles.size();++p)
  {
    stream << triangles[p].pts[0] << " " << triangles[p].pts[1] << " " << triangles[p].pts[2]<< " " << triangles[p].info.length() <<" " << triangles[p].info << std::endl;
  }
  stream << "proptriangles " << proptriangles.size() << std::endl;
  for(int p=0;p< proptriangles.size();++p)
  {
    stream << "from " << proptriangles[p].second << std::endl;
    properties pr=proptriangles[p].first;
    stream << (int)pr.c.R  << " " << (int)pr.c.G << " " <<(int) pr.c.B << " " << (int)pr.c.A << " " ;
    stream << pr.thickness << " " << pr.pointsize << " " << pr.edgeon << " " << pr.edgethickness << " ";
    stream << (int)pr.edgecolor.R << " " <<(int)pr.edgecolor.G << " " <<(int)pr.edgecolor.B << " " <<(int)pr.edgecolor.A << " ";
    stream << pr.teston << " " << pr.nb_uid << " ";
    for (int i=0;i<pr.nb_uid;++i) stream << pr.uids[i] << " "; 
    stream << std::endl;
  }
  
  stream << "quads " << quads.size() << std::endl;
  for(int p=0;p< quads.size();++p)
  {
    stream << quads[p].pts[0] << " " << quads[p].pts[1] << " " << quads[p].pts[2]<< " " << quads[p].pts[3]<< " "<< quads[p].info.length() << " " << quads[p].info << std::endl;
  }
  stream << "propquads " << propquads.size() << std::endl;
  for(int p=0;p< propquads.size();++p)
  {
    stream << "from " << propquads[p].second << std::endl;
    properties pr=propquads[p].first;
    stream << (int)pr.c.R  << " " << (int)pr.c.G << " " <<(int) pr.c.B << " " << (int)pr.c.A << " " ;
    stream << pr.thickness << " " << pr.pointsize << " " << pr.edgeon << " " << pr.edgethickness << " ";
    stream << (int)pr.edgecolor.R << " " <<(int)pr.edgecolor.G << " " <<(int)pr.edgecolor.B << " " <<(int)pr.edgecolor.A << " ";
    stream << pr.teston << " " << pr.nb_uid << " ";
    for (int i=0;i<pr.nb_uid;++i) stream << pr.uids[i] << " "; 
    stream << std::endl;
  }
  for(int i=0;i<3;++i)
  {
    stream << "texts " << i << " " << texts[i].size() << std::endl;
    for(int p=0;p< texts[i].size();++p)
    {
      stream << texts[i][p].first.pts << " " << (int) texts[i][p].second.R << " "  << (int) texts[i][p].second.G << " " << (int) texts[i][p].second.B << " " << (int) texts[i][p].second.A<< " "  << texts[i][p].first.info.length() << " "  << texts[i][p].first.info << std::endl;
    }
  }
}

data_container::data_container(void)
{ 
  setcolorpoints(color());
  setcolorlines(color());
  setcolortriangles(color());
  setcolorquads(color());
}

data_container::data_container(const data_container &other)
{ 
  merge(other);
}

void data_container::merge(const data_container &other)
{ 
  int size1,propsize1;

  size1=points.size();
  points.reserve(points.size() + other.points.size() );
  points.insert(points.end(), other.points.begin(), other.points.end());
  proppoints.reserve(proppoints.size() + other.proppoints.size() );
  propsize1=proppoints.size();
  proppoints.insert(proppoints.end(), other.proppoints.begin(), other.proppoints.end());
  if (size1)
  for (int i=propsize1;i<proppoints.size();++i) // adjust links to properties!
    proppoints[i].second+=size1;

  size1=lines.size();
  lines.reserve(lines.size() + other.lines.size() );
  lines.insert(lines.end(), other.lines.begin(), other.lines.end());
  proplines.reserve(proplines.size() + other.proplines.size() );
  propsize1=proplines.size();
  proplines.insert(proplines.end(), other.proplines.begin(), other.proplines.end());
  if (size1)
  for (int i=propsize1;i<proplines.size();++i) // adjust links to properties!
    proplines[i].second+=size1;
  
  
  size1=triangles.size();
  triangles.reserve(triangles.size() + other.triangles.size() );
  triangles.insert(triangles.end(), other.triangles.begin(), other.triangles.end());
  proptriangles.reserve(proptriangles.size() + other.proptriangles.size() );
  propsize1=proptriangles.size();
  proptriangles.insert(proptriangles.end(), other.proptriangles.begin(), other.proptriangles.end());
  if (size1)
  for (int i=propsize1;i<proptriangles.size();++i) // adjust links to properties!
    proptriangles[i].second+=size1;

  size1=quads.size();
  quads.reserve(quads.size() + other.quads.size() );
  quads.insert(quads.end(), other.quads.begin(), other.quads.end());
  propquads.reserve(propquads.size() + other.propquads.size() );
  propsize1=propquads.size();
  propquads.insert(propquads.end(), other.propquads.begin(), other.propquads.end());
  if (size1)
  for (int i=propsize1;i<propquads.size();++i) // adjust links to properties!
    propquads[i].second+=size1;

  for (int i=0;i<3;++i)
  {
    texts[i].reserve(texts[i].size() + other.texts[i].size() );
    texts[i].insert(texts[i].end(), other.texts[i].begin(), other.texts[i].end());
  }
}


void data_container::clear(void)
{
  points.clear();
  lines.clear();
  triangles.clear();
  quads.clear();
  proppoints.clear();
  proplines.clear();
  proptriangles.clear();
  propquads.clear();
  setcolorpoints(color());
  setcolorlines(color());
  setcolortriangles(color());
  setcolorquads(color());
}

const color& data_container::getcolorpoints(int i) const 
{ 
  return proppoints[i].first.c;
}

const color& data_container::getcolorlines(int i) const
{
  return proplines[i].first.c;
}

const color& data_container::getcolortriangles(int i) const
{
  return proptriangles[i].first.c;
}

const color& data_container::getcolorquads(int i) const
{
  return propquads[i].first.c;
}

const properties& data_container::getproppoints(int i) const 
{ 
  return proppoints[i].first;
}

const properties& data_container::getproplines(int i) const
{
  return proplines[i].first;
}

const properties& data_container::getproptriangles(int i) const
{
  return proptriangles[i].first;
}

const properties& data_container::getpropquads(int i) const
{
  return propquads[i].first;
}


const properties data_container::getproppoints() const 
{ 
  if (getnumproppoints()!=0)
  return proppoints[getnumproppoints()-1].first;
  else
    return properties();
}

const properties data_container::getproplines() const
{
  if (getnumproplines()!=0)
  return proplines[getnumproplines()-1].first;
  else
    return properties();
}

const properties data_container::getproptriangles() const
{
  if (getnumproptriangles()!=0)
  return proptriangles[getnumproptriangles()-1].first;
  else
    return properties();
}

const properties data_container::getpropquads() const
{
  if (getnumpropquads()!=0)
  return propquads[getnumpropquads()-1].first;
  else
    return properties();
}




int data_container::getindexpoints(int i) const 
{ 
  return proppoints[i].second;
}

int data_container::getindexlines(int i) const
{
  return proplines[i].second;
}

int data_container::getindextriangles(int i) const
{
  return proptriangles[i].second;
}

int data_container::getindexquads(int i) const
{
  return propquads[i].second;
}

int data_container::getnumproppoints(void) const
{
  return proppoints.size();
}

int data_container::getnumproplines(void) const
{
  return proplines.size();
}

int data_container::getnumproptriangles(void) const
{
  return proptriangles.size(); 
}

int data_container::getnumpropquads(void) const
{
  return propquads.size();
}

void data_container::setcolorpoints(color c)
{
  properties p=getproppoints();
  p.c=c;
  setproppoints(p);
}

void data_container::setcolorlines(color c)
{
  properties p=getproplines();
  p.c=c;
  setproplines(p);
}

void data_container::setcolortriangles(color c)
{
  properties p=getproptriangles();
  p.c=c;
  setproptriangles(p);
}

void data_container::setcolorquads(color c)
{
  properties p=getpropquads();
  p.c=c;
  setpropquads(p);
}

void data_container::setproppoints(properties p)
{
  proppoints.push_back(std::make_pair(p,points.size()));
}

void data_container::setproplines(properties p)
{
  proplines.push_back(std::make_pair(p,lines.size()));
}


void data_container::setproptriangles(properties p)
{
  proptriangles.push_back(std::make_pair(p,triangles.size()));
}

void data_container::setpropquads(properties p)
{
  propquads.push_back(std::make_pair(p,quads.size()));
}

void data_container::setpropall(properties p)
{
  proppoints.push_back(std::make_pair(p,points.size()));
  proplines.push_back(std::make_pair(p,lines.size()));
  proptriangles.push_back(std::make_pair(p,triangles.size()));
  propquads.push_back(std::make_pair(p,quads.size()));
}

int data_container::add_point(const point& src)
{
  points.push_back(src);
  return points.size()-1;
}

int data_container::add_point(const npoint3& src)
{
  point p;p.pts=src;
  points.push_back(p);
  return points.size()-1;
}

int data_container::add_line(const line& src)
{
  lines.push_back(src);
  return lines.size()-1;
}

int data_container::add_triangle(const triangle& src)
{
  triangles.push_back(src);
  return triangles.size()-1;
}

int data_container::add_quad(const quad& src)
{
  quads.push_back(src);
  return quads.size()-1;
}

int data_container::add_text(int num,const std::pair<point,color>& src)
{
  texts[num].push_back(src);
  return texts[num].size()-1;
}
int data_container::nb_points(void) const
{
  return points.size();
}

int data_container::nb_lines(void) const
{
  return lines.size();
}

int data_container::nb_triangles(void) const
{
  return triangles.size();
}

int data_container::nb_quads(void) const
{
  return quads.size();
}

int data_container::nb_texts(int num) const
{
  return texts[num].size();
}

const point& data_container::get_point(int i) const
{
  return points[i];
}

const line& data_container::get_line(int i) const
{
  return lines[i];
}

const triangle& data_container::get_triangle(int i) const
{
  return triangles[i];
}

const quad& data_container::get_quad(int i) const
{
  return quads[i];
}
const point& data_container::get_text(int num,int i) const
{
  return texts[num][i].first;
}
const color& data_container::get_text_color(int num,int i) const
{
  return texts[num][i].second;
}

point& data_container::get_point(int i)
{
  return points[i];
}

line& data_container::get_line(int i)
{
  return lines[i];
}

triangle& data_container::get_triangle(int i)
{
  return triangles[i];
}

quad& data_container::get_quad(int i)
{
  return quads[i];
}
point& data_container::get_text(int num,int i)
{
  return texts[num][i].first;
}
color& data_container::get_text_color(int num,int i)
{
  return texts[num][i].second;
}
