// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <vector>
#include <set>
#include <stack>
#include <algorithm>
#include <limits>
#include <stdexcept>

#include "nutil.h"
#include "ndisplay.h"

enum
{
  UPPER = 1,
  LOWER = 2,
  DIAGONAL = 3,
  NOT_DIAGONAL = 4 // Tag for marking that a edge is not a diagonal
};

// Declaration of data structures.
struct vertex;

// An edge is pointing to its boundary vertices
// and to its corresponding vertex (if it exists)
struct edge
{
    edge(vertex *_v1, vertex *_v2, int _tag = DIAGONAL)
    {
        v1 = _v1;
        v2 = _v2;
        tag = _tag;
    }
    int tag;
    vertex *v1;
    vertex *v2;
};

// A vertex holds its point coordinates
// and is pointing to its adjacent edges
struct vertex
{
    vertex()
    {
      id = tag = -1;
      e1 = e2 = NULL;
    }
    vertex(int _id, npoint2 _p)
    {
        id = _id;
        p = _p;
        tag = -1;
        e1 = NULL;
        e2 = NULL;
    }
    int id;
    int tag;
    npoint2 p;
    edge *e1;
    edge *e2;
};

// Comparison functor for points.
class Compare_points_2D
{
public:
  bool operator()(const vertex* a, const vertex* b) const
  {
    if(a->p[0] < b->p[0]) return true;
    else if((a->p[0] == b->p[0]) && (a->p[1] < b->p[1])) return true;
    return false;
  }
};

// Declaration of prototypes
void fill_vertices(std::vector<vertex> &v);
void create_polygon(std::vector<edge> &polygon, std::vector<vertex> &v);
void show_polygon(data_container &data, const std::vector<edge> &polygon);
void tag_vertices(std::vector<vertex> &vertices);
void print_tags(std::vector<vertex> const &v);
double compute_angle(const vertex &v0, const vertex &v1, const vertex &v2);
void make_triangulation(std::vector<edge> const &polygon_0, std::vector<edge> &polygon);

// main function
int main(int argc, char** argv)
{
  // Visualization
  std::vector<data_container> buffer(1);
  data_container &data=buffer[0];
  ndisplay display;                 // Display window

  std::vector<vertex> vertices;

  fill_vertices(vertices);

  std::vector<edge> polygon_0; // Monotone polygon in the x-direction defined by line in an anti-clockwise fashion.
  create_polygon(polygon_0, vertices);
  std::vector<edge> polygon = polygon_0;

  make_triangulation(polygon_0, polygon);

  show_polygon(data, polygon);
  display.init_data(buffer);
  display.display();

  return 0;
}

// Create vertices for the polygon
void fill_vertices(std::vector<vertex> &v)
{
  // Polygon from the presentation. Uncomment to use.
/*  v.push_back(vertex(0, npoint2(0.1, 0.1)));
  v.push_back(vertex(1, npoint2(0.2, 0.05)));
  v.push_back(vertex(2, npoint2(0.25, 0.15)));
  v.push_back(vertex(3, npoint2(0.4, 0.2)));
  v.push_back(vertex(4, npoint2(0.5, 0.1)));
  v.push_back(vertex(5, npoint2(0.6, 0.2)));
  v.push_back(vertex(6, npoint2(0.55, 0.5)));
  v.push_back(vertex(7, npoint2(0.5, 0.4)));
  v.push_back(vertex(8, npoint2(0.47, 0.3)));
  v.push_back(vertex(9, npoint2(0.35, 0.25)));
  v.push_back(vertex(10, npoint2(0.3, 0.225)));*/

  // Comment this if you use the polygon from the presentation.
  v.push_back(vertex(1, npoint2(9.0, 4.0)));
  v.push_back(vertex(2, npoint2(8.5, 3.0)));
  v.push_back(vertex(3, npoint2(7.5, 3.0)));
  v.push_back(vertex(4, npoint2(6.5, 1.5)));
  v.push_back(vertex(5, npoint2(5.5, 1.0)));
  v.push_back(vertex(6, npoint2(2.0, 3.0)));
  v.push_back(vertex(7, npoint2(0.0, 1.0)));
  v.push_back(vertex(8, npoint2(1.0, -1.0)));
  v.push_back(vertex(9, npoint2(3.0, 0.0)));
  v.push_back(vertex(10, npoint2(4.0, 1.55)));
  v.push_back(vertex(11, npoint2(10.0, -3.0)));
  v.push_back(vertex(12, npoint2(11, 1.5)));
}

// Create a polygon with lines in an anti-clokwise fashion.
void create_polygon(std::vector<edge> &polygon, std::vector<vertex> &v)
{
  polygon.clear();

  for (int i=0; i<v.size()-1; i++)
    polygon.push_back(edge(&v[i], &v[i+1], NOT_DIAGONAL));

  polygon.push_back(edge(&v[v.size()-1], &v[0], NOT_DIAGONAL));

  for (int j=1; j<v.size(); j++)
  {
    v[j].e1 = &polygon[j-1];
    v[j].e2 = &polygon[j];
  }
  v[0].e1 = &polygon[polygon.size()-1];
  v[0].e2 = &polygon[0];

  tag_vertices(v);
}

// Show a polygon on the screen.
void show_polygon(data_container &data, const std::vector<edge> &polygon)
{
  {
    properties ptr = data.getproppoints();
    ptr.pointsize = 3;
    data.setproppoints(ptr);
  }

  for(size_t i = 0; i < polygon.size(); i++)
  {
    const edge &l = polygon[i];
    data.add_point(l.v1->p);
    data.add_point(l.v2->p);
    if(l.tag != DIAGONAL)
      data.add_line(line(l.v1->p, l.v2->p));
  }

  // Add diagonals with a different colour.
  data.setcolorlines(color(0, 255, 0));

  for(size_t i = 0; i < polygon.size(); i++)
  {
    const edge &l = polygon[i];
    if(l.tag == DIAGONAL)
      data.add_line(line(l.v1->p, l.v2->p));
  }
}

// Tag vertices following they are on the upper or lower chain in linear time.
void tag_vertices(std::vector<vertex> &vertices)
{
  for(size_t i = 0; i < vertices.size(); i++)
  {
    const edge* e2 = vertices[i].e2;
    if(e2->v2->p[0] > vertices[i].p[0])
    {
      vertices[i].tag = LOWER;
      continue;
    }

    if((e2->v2->p[0] == vertices[i].p[0]) && (e2->v2->p[1] > vertices[i].p[1]))
    {
      vertices[i].tag = LOWER;
      continue;
    }

    vertices[i].tag = UPPER;
  }
}

void print_tags(std::vector<vertex> const &v)
{
    for(size_t i=0; i<v.size(); i++)
    {
        std::cout<<"vertex no. "<<v[i].id<<", tag: "<<v[i].tag<<"\n";
    }
}

// Compute the angle between two the two edges defined
// by three vertices v0, v1, v2 as follow:
//  e1 links v0 to v2
//  e2 links v0 to v1
double compute_angle(const vertex &v0, const vertex &v1, const vertex &v2)
{
    npoint2 vec1 = v2.p - v0.p;
    npoint2 vec2 = v1.p - v0.p;
    vec1.normalize();
    vec2.normalize();

    return atan2(crossprod(vec1, vec2), vec1*vec2);
}

// Check if it is possible to draw a diagonal between
// two vertices on a monotone polygon.
bool check_diagonal(const vertex &_v, const vertex &_w)
{
  // TO BE IMPLEMENTED...
  // Check if a diagonal inside the polygon can be drawn between
  // vertices _v or _w.
  //
  // To this aim, you may use the 'compute_angle' function.
  //
  // Note: vertices may, or may not belong to the same chain.
  return false; // Remove this line.
}

// General function triangulating a monotone polygon.
void make_triangulation(std::vector<edge> const &polygon_0, std::vector<edge> &polygon)
{
  // TO BE IMPLEMENTED...
  // First, do a copy of the vertices of polygon_0 and sort them
  // by lexicographical order using the standard function std::sort
  // and the functor 'Compare_points_2D'.
  //
  // Then, determine and draw the diagonals inside 'polygon'.
  // For this, use the algorithm described on page 48 of the cource CADCG_07.
  //
  // Use the standard class 'std::stack' which implements a stack.
  //
  // Note: vertices have been already tagged as belonging to the UPPER or LOWER chain.
}
