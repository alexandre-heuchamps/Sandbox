// Gnurbs - A curve and surface library
// Copyright (C) 2008-2014 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>

#include "nlagrange.h"
#include "ndisplay.h"
#include "nutil.h"
#include "gnurbscallbacks.h"

// Initialization function prototype
// the complete implementation can be found at the end of the file
// DX and DY are the offsets with respect to the origin

void init_lagrange(nlagrange &curve,double DX,double DY);
void init_lagrange_helix(nlagrange &curve, double r);

// main function

int main(void)
{
  data_container data;                // Contains data to display
  ndisplay display;                   // Display window
  int nCP1=7;                         // Number of control points for the half-circle
  int nCP=15;                         // Number of control points for the helix
  double r = 5.0;                     // Helix radius

  nlagrange curve1(nCP1);             // Lagrange curve with nCP control points
  nlagrange curve_helix(nCP);

  init_lagrange(curve1,0.,0.);        // Curve initialization
  init_lagrange_helix(curve_helix, r);

  gnurbscallbacks CB;
  CB.add_entity(&curve1);
  CB.add_entity(&curve_helix);

  display.setcallbacks(&CB);
  CB.draw();
  display.init_data(CB.datas);        // Transfer of the data to display
  display.display();                  // Display loop
  return 0;
}

void init_lagrange(nlagrange &curve,double DX,double DY)
{
// Insert your code here.
}

void init_lagrange_helix(nlagrange &curve, double r)
{
// Insert your code here.
}
