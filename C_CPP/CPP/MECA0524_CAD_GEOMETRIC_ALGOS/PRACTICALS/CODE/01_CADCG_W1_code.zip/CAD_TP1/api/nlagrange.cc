// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nlagrange.h"

#include <cmath>


double nlagrange::Basis(int which,double u_) const
{
// Insert your code here.
}

void nlagrange::P(double u_, npoint& ret) const
{
// Insert your code here.
}

void nlagrange::translate(npoint vec)
{
  for (int i=0;i<nCP;++i) val[i]+=vec;
}
