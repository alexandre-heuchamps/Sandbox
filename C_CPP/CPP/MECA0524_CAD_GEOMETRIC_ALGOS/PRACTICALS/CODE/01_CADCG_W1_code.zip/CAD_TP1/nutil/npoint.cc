#include "npoint.h"

npoint::npoint(const npoint3 pt, const double w)
{
  for (int i=0;i<3;++i) coord[i]=pt[i]*w;
  coord[3]=w;
}

npoint::npoint(const npoint2 pt, const double w)
{
  for (int i=0;i<2;++i) coord[i]=pt[i]*w;
  coord[2]=0;
  coord[3]=w;
}

npoint::npoint(const double pt, const double w)
{
  coord[0]=pt*w;
  coord[1]=0;
  coord[2]=0;
  coord[3]=w;
}

npoint operator * (const double fact,const npoint other)
{
  npoint buf=other;
  for (int i=0;i<4;++i) buf[i]*=fact;
  return buf;
}

npoint3 crossprod(const npoint3  V1,const npoint3 V2)
{
  npoint3 buf;
  buf[0]=V1[1]* V2[2]-V1[2]* V2[1];
  buf[1]=V1[2]* V2[0]-V1[0]* V2[2];
  buf[2]=V1[0]* V2[1]-V1[1]* V2[0];
  return buf;
}


npoint3 operator * (const double fact,const npoint3 other)
{
  npoint3 buf=other;
  for (int i=0;i<3;++i) buf[i]*=fact;
  return buf;
}

double operator * (const npoint3 p1, const npoint3 p2)
{
  double scalaire = p1.x() *p2.x() + p1.y() *p2.y() + p1.z() *p2.z();

  return scalaire;

}


void npoint::print(std::ostream &os,int prec) const                        // sort les coordonees dans le flux os
{
  os.precision(prec);
  os.flags(std::ios::scientific);
  os<<coord[0]<<" "<<coord[1]<<" "<<coord[2]<<" "<<coord[3];
}

void npoint3::print(std::ostream &os,int prec) const                         // sort les coordonees dans le flux os
{
  os.precision(prec);
  os.flags(std::ios::scientific);
  os<<coord[0]<<" "<<coord[1]<<" "<<coord[2];
}

std::ostream& operator<<(std::ostream& stream, 
                     const npoint& pt)
{
  pt.print(stream,16); //assuming you define print for matrix 
  return stream;
}


std::ostream& operator<<(std::ostream& stream, 
                     const npoint3& pt)
{
  pt.print(stream,16); //assuming you define print for matrix 
  return stream;
}

npoint3::npoint3(const npoint2 p)
{
  coord[0]=p.u();
  coord[1]=p.v();
  coord[2]=0;
}


double crossprod(const npoint2  V1,const npoint2 V2)
{
  return V1[0]* V2[1]-V1[1]* V2[0];
}

npoint2 operator * (const double fact,const npoint2 other)
{
  npoint2 buf=other;
  for (int i=0;i<2;++i) buf[i]*=fact;
  return buf;
}

double operator * (const npoint2 p1, const npoint2 p2)
{
  double scalaire = p1.u() *p2.u() + p1.v() *p2.v();

  return scalaire;

}

