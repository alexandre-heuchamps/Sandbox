// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "mousewheelbackwardCallback.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkRenderWindow.h"

void mousewheelbackwardCallback::Execute(vtkObject *caller, unsigned long, void*)
{
  vtkRenderWindowInteractor *interactor = reinterpret_cast<vtkRenderWindowInteractor*>(caller);
  int x,y;
  interactor->GetMousePosition(&x,&y);
  
  myDisplay->mousewheelbackwardCall(x,y);
}
