// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "ndisplaytofile.h"
#include <cstring>
#include <iostream>

ndisplaytofile::ndisplaytofile(color _c,const  char* _name,std::ostream &out_): data(0x0),data2(0x0),out(out_)
{
  if (_name)
  {
    name=new char[strlen(_name)+1];
    strcpy(name,_name);
  }
  else
    name=NULL;
  c=_c;
}

ndisplaytofile::~ndisplaytofile()
{
  if (name) delete[] name;
  if (data2) delete data2;
}

void ndisplaytofile::display()
{
  if (ncb)
  {
    const std::vector<data_container> *datas=ncb->get_data();
    if (datas)
    {
      ncb->draw();
      init_data(*datas);
    }
    else
    {
      ncb->draw();
    }
  }
  int ndata=data->size();
  out << "data " << ndata << std::endl;
  for (int i=0;i<ndata;++i)
  {
    (*data)[i].print(out);
  }
}

void ndisplaytofile::init_data(const data_container &data_)
{
  std::vector<data_container>*data__=new std::vector<data_container>;
  data__->push_back(data_);
  data=data__;
  data2=data__;
}

void ndisplaytofile::init_data()
{
  std::vector<data_container>*data__=new std::vector<data_container>;
  data__->push_back(data_container());
  data=data__;
  data2=data__;
}

void ndisplaytofile::init_data(const std::vector< data_container >& datas_)
{
  data=&datas_;
}
