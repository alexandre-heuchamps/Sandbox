// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//
// Contributions Sebastien MOREAU

#ifndef __NVTKCURVEREP_H
#define __NVTKCURVEREP_H


#include "vtkOrientedGlyphContourRepresentation.h"
class ncurve;

class nvtkCurveRep : public vtkOrientedGlyphContourRepresentation
{
public:

  // Description:
  // Instantiate this class.
  static nvtkCurveRep *New();

  // Description:
  // Standard methods for instances of this class.
  vtkTypeMacro(nvtkCurveRep,vtkOrientedGlyphContourRepresentation);

  void SetCurve(ncurve *courbe);

  void BuildLines();

  virtual double* GetBounds();

protected:
  nvtkCurveRep();
  ~nvtkCurveRep();

  double Bounds [6];
private:
  ncurve * _curve;

  nvtkCurveRep(const nvtkCurveRep&);     //Not implemented
  void operator= (const nvtkCurveRep&);    //Not implemented

};


#endif// __NVTKCURVEREP_H
