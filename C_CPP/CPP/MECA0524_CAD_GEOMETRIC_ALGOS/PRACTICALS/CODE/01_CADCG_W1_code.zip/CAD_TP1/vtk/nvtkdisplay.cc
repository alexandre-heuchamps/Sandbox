// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nvtkdisplay.h"
#include "nvtkCurveRep.h"
#include "keyboardCallback.h"

#include <vtkCellArray.h>
#include <vtkCellData.h>
#include <vtkDoubleArray.h>
#include <vtkPoints.h>
#include <vtkVertex.h>
#include <vtkLine.h>
#include <vtkTriangle.h>
#include <vtkQuad.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkTubeFilter.h>
#include <vtkCleanPolyData.h>
#include <vtkCubeSource.h>
#include <vtkSphereSource.h>
#include <vtkGlyph3D.h>
#include <vtkProperty.h>
#include "vtkCamera.h"

void nvtkdisplay::add_curve(ncurve *curve, color cp,color cl)
{
  curves.push_back(curve);
  nvtkCurveRep *aCurveRep = nvtkCurveRep::New();
  double rp=cp.R/255.;
  double gp=cp.G/255.;
  double bp=cp.B/255.;
  aCurveRep->GetProperty()->SetColor(rp,gp,bp);
  double rl=cl.R/255.;
  double gl=cl.G/255.;
  double bl=cl.B/255.;
  aCurveRep->GetLinesProperty()->SetColor(rl,gl,bl);
  aCurveRep->SetLineInterpolator(NULL);
  vtkContourWidget *contourWidget = vtkContourWidget::New();
  contourWidget->SetInteractor(renderWindowInteractor);
  contourWidget->SetRepresentation(aCurveRep);
  contourWidget->On();
  aCurveRep->VisibilityOn();
  aCurveRep->SetCurve(curve);
  vtkcurves.push_back(aCurveRep);
  vtkcurvewidgets.push_back(contourWidget);

  // quite strange code which initialize contourWidget with nothing
  // but set status to Manipulate
  vtkPolyData * pd = vtkPolyData::New();
  vtkPoints    *points      = vtkPoints::New();
//  vtkCellArray *lines       = vtkCellArray::New();
  pd->SetPoints(points);
//  pd->SetLines(lines);
  contourWidget ->Initialize(pd);
  points->Delete();
//  lines->Delete();
//  contourWidget->Render();
//  renderer->ResetCamera();
}
