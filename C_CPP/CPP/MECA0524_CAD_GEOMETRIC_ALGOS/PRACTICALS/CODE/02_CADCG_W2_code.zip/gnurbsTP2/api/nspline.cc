// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nspline.h"

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "linear_algebra.h"

void nspline::P(double u_, npoint& ret) const
{
  // You have to implement this.

}

void nspline::compute_FD(void)
{
  type=FiniteDifferences;

  // You have to implement this.
}

void nspline::compute_cardinal(double c)
{
  card=c;
  type=Cardinal;

  // You have to implement this.
}

void nspline::compute_natural(void)
{
  type=Natural;

  // You have to implement this.
}

void nspline::tridiagsolve(std::vector<double> &rhs) // fast linear solver
{
  int n=nb_CP();
  std::vector<double> c(n);
  double h0=u(1)-u(0);
  c[0]=h0;
  double b0=2*h0;
  c[0] /= b0;
  rhs[0] /= b0;
  for (int i = 1; i < n-1; i++)
  {
    double hi=u(i+1)-u(i);
    double him1=u(i)-u(i-1);
    double bi=2*hi+2*him1;
    double ai=hi;
    c[i] = him1;
    double id=1 / (bi - c[i-1] * ai);
    c[i]*=id;
    rhs[i] = (rhs[i] - rhs[i-1] * ai) * id;
  }
  int i=n-1;
  double him1=u(i)-u(i-1);
  double bi=2*him1;
  double ai=him1;
  double id=1 / (bi - c[i-1] * ai);
  rhs[i] = (rhs[i] - rhs[i-1] * ai) * id;

  for (int i = n - 2; i >= 0; i--)
    rhs[i] = rhs[i] - c[i] * rhs[i + 1];
}


void nspline::tridiagsolve_circulant(LU_Matrix &LU,std::vector<double> &rhs) // somewhat slow due to general LU factorization (done once).
{
  int n=nb_CP();

  Vector Rhs(n-1);
  for (int i = 0; i < n-1; i++) Rhs(i)=rhs[i];
  Vector Sol(n-1);
  LU.Solve_Linear_System(Rhs,Sol);
  for (int i = 0; i < n-1; i++) rhs[i]=Sol(i);
}

void nspline::update()
{
  switch (type)
  {
    case FiniteDifferences :
      compute_FD();
      break;
    case Cardinal :
      compute_cardinal(card);
      break;
    case Natural :
      compute_natural();
      break;
  }
}
