// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include "nlagrange.h"

#include <cmath>


double nlagrange::Basis(int which,double u_) const
{
  int i=which;
  double weight = 1;
  for (int j = 0; j < nCP; ++j)
  {
    // The i-th term has to be skipped
    if (j != i)
    {
      weight *= (u_ - pos[j]) / (pos[i] - pos[j]);
    }
  }
  return weight;
}

void nlagrange::P(double u_, npoint& ret) const
{
  for (int k =0 ; k<4;++k)   ret[k]=0;
  for (int i = 0; i < nCP; ++i)
  {
    double weight=Basis(i,u_);
    ret += weight * val[i];
  }
}

void nlagrange::translate(npoint vec)
{
  for (int i=0;i<nCP;++i) val[i]+=vec;
}
