// Gnurbs - A curve and surface library
// Copyright (C) 2008-2019 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#ifndef __GNURBSCALLBACKS_H
#define __GNURBSCALLBACKS_H


#include "ndisplay_base.h"
#include "npoint.h"
#include "ndata.h"
#include "nentity.h"

class gnurbscallbacks : public ncallbacks
{
public:
  gnurbscallbacks():picked(0x0) {}
  virtual ~gnurbscallbacks() {}
  virtual int pick_callback(int,pickinfo[],npoint3);
  virtual int drag_callback(npoint3,npoint3,pickinfo);
  virtual int release_callback(npoint3,npoint3,pickinfo);
  virtual std::string get_info(pickinfo);
  virtual void draw(void); //redraw everything
  virtual void draw(int i); // draw one element (and keep the others)
  virtual int add_entity(nentity* ent) {objects.push_back(ent);prop_objects.push_back(properties());datas.push_back(data_container()); return (objects.size()-1);}
  virtual int add_entity(nentity* ent,properties p) {objects.push_back(ent);prop_objects.push_back(p);datas.push_back(data_container()); return (objects.size()-1);}
  virtual const std::vector<data_container>* get_data() {return &datas;}
  std::vector<nentity*> objects;
  std::vector<properties> prop_objects;
  std::vector<data_container> datas;
  nentity *picked;
};

#endif //__GNURBSCALLBACKS_H
