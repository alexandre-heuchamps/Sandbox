// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//


#include "nutil.h"
#include <cstdio>
#include "fltkdisplay.h"
#include "nfltkwindow.h"
#include <FL/Fl_Menu_Item.H>

class mycallbacks : public ncallbacks
{
public:
  mycallbacks(fltkdisplay *fd_): data(0),fd(fd_),adding_point(false),adding_line(false),nbadded(0) {}
  virtual int pick_callback(int,pickinfo[],npoint3);
  virtual int drag_callback(npoint3,npoint3,pickinfo);
  virtual int release_callback(npoint3 , npoint3 , pickinfo );
  virtual int key_callback(int,const char *);
  data_container *data;
  fltkdisplay *fd;
  point porig;
  line lorig;
  triangle torig;
  quad qorig;
  bool adding_point=false;
  bool adding_line=false;
  line l;
  int nbadded;
};

void Test_callback(Fl_Widget* w, void* p);
void AddPoint_callback(Fl_Widget* w, void* p);
void AddLine_callback(Fl_Widget* w, void* p);

Fl_Menu_Item menuitems_custom[] = {
 { "&Custom",              0, 0, 0, FL_SUBMENU },
    { "&Reset Window Size",  0, (Fl_Callback *)Test_callback},
    { "Add &Point",  0, (Fl_Callback *)AddPoint_callback},
    { "Add &Line",  0, (Fl_Callback *)AddLine_callback},
    { 0 }
};


void Test_callback(Fl_Widget* w, void* p)
{
  mycallbacks *m=(mycallbacks*)p;
  fltkdisplay *fd=m->fd;
  nFltkWindow *win = fd->win;
  win->resize(win->x(),win->y(),800,600);
  fd->reset_view();
}


void AddPoint_callback(Fl_Widget* w, void* p)
{
  mycallbacks *m=(mycallbacks*)p;
  fltkdisplay *fd=m->fd;
  nFltkWindow *win = fd->win;
  m->adding_point=true;
}

void AddLine_callback(Fl_Widget* w, void* p)
{
  mycallbacks *m=(mycallbacks*)p;
  fltkdisplay *fd=m->fd;
  nFltkWindow *win = fd->win;
  m->adding_line=true;
}

int mycallbacks::key_callback(int key,const char* txt)
{
  switch(key)
  {
  case FL_Escape : // cancel current input
    adding_point=false;
    adding_line=false;
    nbadded=0;
    return 1;
  }
  return 0; // do not catch all other keys.
}

int mycallbacks::pick_callback(int nb, pickinfo picks[],npoint3 p)
{
  std::cout << "num=" << nb << std::endl;
  for(unsigned int j = 0; j < nb; j++)
  {
    std::cout << "t=" << picks[j].type << " id=" << picks[j].id << " ";
    for (int i=0;i<picks[j].nb_uid;++i) 
      std::cout << "uid" << i << "=" << picks[j].uids[i] << " " ;
    std::cout << picks[j].z  << std::endl;
  }
  if (adding_point)
  {
    data->add_point(p);
    adding_point=false;
  }
  else if (nb)
  {
    if (adding_line)
    {
      if (picks[0].id!=-1)
      {
        if(picks[0].type==1)
        {
          l.pts[nbadded++]=p;
          if (nbadded==2)
          {
            data->add_line(l);nbadded=0;
            adding_line=false;
          }
        }
      }
    }
    else
    if (picks[0].id!=-1)
    {
      switch(picks[0].type)
      {
        case 1: // points
        {
          porig=data->get_point(picks[0].id);
          break;
        }
        case 2: // lines
        {
          lorig=data->get_line(picks[0].id);
          break;
        }
        case 3: // triangles
        {
          torig=data->get_triangle(picks[0].id);
          break;
        }
        case 4: // quads
        {
          qorig=data->get_quad(picks[0].id);
          break;
        }
      }
      return 0; // first element in the stack (closest to the eye) is chosen (-1 if no pick wanted)
    }
  }
  return -1;
}

int mycallbacks::drag_callback(npoint3 orig,npoint3 p, pickinfo pick)
{
  int ret=0; // no redraw by default
//  p.print(std::cout);
  if (pick.id!=-1)
  {
    switch(pick.type)
    {
      case 1: // points
      {
        data->get_point(pick.id).pts=p;
        ret=1; // redraw
        break;
      }
      case 2: // lines
      {
        npoint3 dp=p-orig;
        for (int i=0;i<2;++i)
          data->get_line(pick.id).pts[i]=lorig.pts[i]+dp;
        ret=1; // redraw
        break;
      }
      case 3: // triangles
      {
        npoint3 dp=p-orig;
        for (int i=0;i<3;++i)
          data->get_triangle(pick.id).pts[i]=torig.pts[i]+dp;
        ret=1; // redraw
        break;
      }
      case 4: // quads
      {
        npoint3 dp=p-orig;
        for (int i=0;i<4;++i)
          data->get_quad(pick.id).pts[i]=qorig.pts[i]+dp;
        ret=1;
        break;
      }
      default : // else no redraw
        break;
    }
  }
  return ret;
}

int mycallbacks::release_callback(npoint3 orig,npoint3 p, pickinfo pick)
{
  adding_point=false;
  if ((adding_line)&&(nbadded==2)) {adding_line=false;nbadded=0;}
  return 0;
}

int main(void)
{
  std::vector<data_container> buffer(1);
  data_container &data=buffer[0];


  npoint p1(0,0,0),p2(1,0,0),p3(1,1,0),p4(0,1,0),
  p5(0,0,1),p6(1,0,1),p7(1,1,1),p8(0,1,1);
  
  properties ptr=data.getproppoints();
  ptr.c=color(100,200,60);
  ptr.pointsize=15;
  ptr.nb_uid=1;
  ptr.uids[0]=1;
  data.setproppoints(ptr);
  data.add_point(p1);
  data.add_point(p2);
  data.add_point(p3);
  data.add_point(p4);
  ptr.c=color(255,0,255);
  ptr.pointsize=7;
  ptr.uids[0]=2;
  data.setproppoints(ptr);
  data.add_point(p5);
  data.add_point(p6);
  data.add_point(p7);
  data.add_point(p8);
  data.add_point(npoint(0.5,0.5,0.5));

  
  ptr=data.getproptriangles();
  ptr.c=color(255,0,0);
  ptr.edgeon=true;
  ptr.edgecolor=color(255,255,255);
  ptr.edgethickness=5;
  ptr.nb_uid=2;
  ptr.uids[0]=14;
  ptr.uids[1]=69;
  
  data.setproptriangles(ptr);
  
  triangle tr;
  tr.pts[0]= npoint3(0,0.5,0.5);
  tr.pts[1]= npoint3(0.5,0,0.5);
  tr.pts[2]= npoint3(0.5,0.5,0);
  data.add_triangle(tr);
  ptr.c=color(0,0,255);
  ptr.edgeon=false;
  ptr.nb_uid=0;
  data.setproptriangles(ptr);
  tr.pts[0]= npoint3(0,-0.5,-0.5);
  tr.pts[1]= npoint3(-0.5,0,-0.5);
  tr.pts[2]= npoint3(-0.5,-0.5,0);
  data.add_triangle(tr);
  
  line l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
  l1.pts[0]=p1;
  l1.pts[1]=p2;
  l2.pts[0]=p2;
  l2.pts[1]=p3;
  l3.pts[0]=p3;
  l3.pts[1]=p4;
  l4.pts[0]=p4;
  l4.pts[1]=p1;
  l5.pts[0]=p5;
  l5.pts[1]=p6;
  l6.pts[0]=p6;
  l6.pts[1]=p7;
  l7.pts[0]=p7;
  l7.pts[1]=p8;
  l8.pts[0]=p8;
  l8.pts[1]=p5;

  l9.pts[0]=p1;
  l9.pts[1]=p5;
  l10.pts[0]=p2;
  l10.pts[1]=p6;
  l11.pts[0]=p3;
  l11.pts[1]=p7;
  l12.pts[0]=p4;
  l12.pts[1]=p8;
  ptr=data.getproplines();
  ptr.c=color(0,125,0);
  ptr.thickness=5;
  data.setproplines(ptr);
  data.add_line(l1);
  data.add_line(l2);
  data.add_line(l3);
  data.add_line(l4);
  ptr.c=color(255,0,0);
  data.setproplines(ptr);
  data.add_line(l5);
  data.add_line(l6);
  ptr.thickness=10;
  data.setproplines(ptr);
  data.add_line(l7);
  data.add_line(l8);
  ptr.thickness=15;
  data.setproplines(ptr);
  data.add_line(l9);
  data.add_line(l10);
  ptr.thickness=2;
  data.setproplines(ptr);
  data.add_line(l11);
  data.add_line(l12);

  quad qu;
  qu.pts[0]=p1;
  qu.pts[1]=p6;
  qu.pts[2]=p7;
  qu.pts[3]=p4;
  ptr=data.getpropquads();
  ptr.c=color(0,255,0,128); // semi-transparent
  ptr.edgeon=false;
  data.setpropquads(ptr);
  data.add_quad(qu);
  qu.pts[0]=p1;
  qu.pts[1]=p2;
  qu.pts[2]=p3;
  qu.pts[3]=p4;
  ptr.c=color(100,100,100,255); 
  data.setpropquads(ptr);
  data.add_quad(qu);
  
  npoint p10(2,2,2);
  point pp;
  pp.pts=p10;
  char mess[255];
  sprintf(mess,"Hello");
  pp.info=mess;
  color cc=color(0,255,255);
  std::pair<point,color> tmp(pp,cc);
  data.add_text(0,tmp);
  fltkdisplay display(color(0,0,0),(char*)"Test FLTK");
  mycallbacks callbacks(&display);
  callbacks.data=&data;
  display.buildMenus(menuitems_custom,&callbacks);
  display.init_data(buffer);
  display.setcallbacks(&callbacks);
  display.allow_pick=true;
  display.display();
  return 0;
}
