// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

//---------------------------------------------------------------------------
#ifndef SPARSE_ITERATOR_H
#define SPARSE_ITERATOR_H
//---------------------------------------------------------------------------

#include <map>

class sparse_iterator;
//class sparse_matrix;

typedef std::map<int,sparse_iterator*> sparse_container;

class sparse_iterator
{
public :
  double& operator*()
  {
    return val;
  };
  int column()
  {
    return (*lptr).first;
  };
  int line()
  {
    return (*cptr).first;
  } ;
  sparse_iterator& nextl()
  {
    sparse_container::iterator ptr=lptr;
    ptr++;
    return (* ((*ptr).second));
  };
  sparse_iterator& nextc()
  {
    sparse_container::iterator ptr=cptr;
    ptr++;
    return (* ((*ptr).second));
  };
  sparse_iterator(double v,sparse_container::iterator li,sparse_container::iterator ci) :lptr(li),cptr(ci),val(v) {};
  sparse_iterator(double v=0.0) :val(v) {};
  bool operator == (const sparse_iterator& other)
  {
    return ((lptr==other.lptr) && (cptr==other.cptr));
  }
  bool operator != (const sparse_iterator& other)
  {
    return !(*this==other);
  }
  sparse_container::iterator lptr;
  sparse_container::iterator cptr;
private :
  double val;
};





#endif //SPARSE_ITERATOR_H
