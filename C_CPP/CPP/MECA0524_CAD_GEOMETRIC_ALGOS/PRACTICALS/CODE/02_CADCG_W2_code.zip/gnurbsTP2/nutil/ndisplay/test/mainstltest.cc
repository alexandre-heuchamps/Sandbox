// nUtil - An utility Library for gnurbs
// Copyright (C) 2008-2021 Eric Bechet
//
// See the LICENSE file for contributions and license information.
// Please report all bugs and problems to <bechet@cadxfem.org>.
//

#include <iostream>
#include <vector>
#include <cstring>
#include <fstream>

using namespace std;

#include "ndisplay.h"


#ifdef INTERFACE_TYPE_FLTK
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Native_File_Chooser.H>
void LoadSTL_callback(Fl_Widget* w, void* p);
Fl_Menu_Item custom_menu_items[] = {
  { "&STL",              0, 0, 0, FL_SUBMENU },
    { "&Load STL file",  0, (Fl_Callback *)LoadSTL_callback},
    { 0 },
};

class mycallbacks : public ncallbacks
{
  std::vector<npoint3> &pts;
  data_container &data;
public:
  mycallbacks(std::vector<npoint3> &pts_,data_container &data_):pts(pts_),data(data_){}
  virtual int pick_callback(int,pickinfo[],npoint3);
  virtual int key_callback(int key, const char* str);
};

int mycallbacks::key_callback(int key, const char* str)
{
  switch ( key )
  {
      case 'k' : pts.clear();data.clear();break;
      case 's' : for (int i=0;i<pts.size();++i) std::cout << pts[i] << std::endl;break;
  }
  return 1; // nothing to be done
}

int mycallbacks::pick_callback(int nb, pickinfo picks[],npoint3 p)
{
/*  std::cout << "num=" << nb << std::endl;
  std::cout << p(0) << " " << p(1) << " " << p(2) << std::endl;
  for(unsigned int j = 0; j < nb; j++)
  {
    std::cout << "t=" << picks[j].type << " id=" << picks[j].id << " ";
    for (int i=0;i<picks[j].nb_uid;++i) 
      std::cout << "uid" << i << "=" << picks[j].uids[i] << " ";
    std::cout << picks[j].z  << std::endl;
  }*/
  if (nb)
  {
    if (picks[0].id!=-1)
    {
        pts.push_back((npoint3)p);
        data.add_point((npoint3)p);
//      std::cout << p(0) << " " << p(1) << " " << p(2) << std::endl;
      return 0; // first element in the stack (closest to the eye) is chosen (-1 if no pick wanted)
    }
  }
  return -1;
}


#endif

//fonction de chargement du maillage STL
void loadmesh(std::string filename,std::vector<triangle> &mesh);

std::vector<data_container> buffer(2);

int main(int argc, char * argv[])
{
//  std::vector<data_container> buffer(2);
  data_container &data=buffer[0];
  data_container &data_pts=buffer[1];
  properties p;
  p.c=color(255,0,0);
  p.pointsize=7;
  data_pts.setproppoints(p);
  ndisplay display;
  #ifdef INTERFACE_TYPE_FLTK
  display.buildMenus(custom_menu_items,&display);
  #endif

//  std::vector<triangle> mesh;
  stlmesh stl;
  if (argc==2)
  {
    try 
    {
//      loadmesh(argv[1],mesh);
      stl.load_stl(argv[1]);
    }
    catch(int)
    {
      std::cout << "Problem reading STL" << std::endl;
    }
  }
  
//  for(int i=0;i<mesh.size();++i) data.add_triangle(mesh[i]);
  stl.Display(data);
  display.init_data(buffer);
  std::vector<npoint3> pts;
  mycallbacks CB(pts,data_pts);
  display.setcallbacks(&CB);
  display.display();
  return 0;
}

#ifndef _WIN32
int stricmp ( const char *s1, const char*s2 )
{
  return strcasecmp ( s1,s2 );
}
#endif

/*//fonction qui charge un fichier STL
void loadmesh(std::string filename,std::vector<triangle> &mesh)
{
  stlmesh stl;
  std::cout << " chargement de " << filename << " ... ";
  unsigned long sz=stl.load_stl(filename);
  mesh.resize(sz);
  for (unsigned long i=0;i<sz;++i)
  {
    triangle t;
    for( int j=0;j<3;++j)
      for( int k=0;k<3;++k)
        mesh[i].pts[j][k]=stl.facets[i].pts[j][k];
  }
  std::cout << mesh.size()  << " triangles."  << std::endl;
}
*/

#ifdef INTERFACE_TYPE_FLTK

void LoadSTL_callback(Fl_Widget* w, void* p)
{
  stlmesh stl;
  ndisplay* disp=(ndisplay*)p;
  Fl_Native_File_Chooser *chooser = new Fl_Native_File_Chooser();
  chooser->type(Fl_Native_File_Chooser::BROWSE_FILE);
  chooser->filter("STL files\t*.stl");
  chooser->title("Read buffer");
  switch ( chooser->show() )
  {
    case -1:    // ERROR
      std::cout << "*** ERROR show() failed:" << chooser->errmsg()<< std::endl;
      break;
    case 1:     // CANCEL
      break;
    default:    // USER PICKED A FILE
      try
      {
        stl.load_stl(chooser->filename());
      }
      catch (int)
      {
        std::cout << "Problem reading STL" << std::endl;
        break;
      }
      buffer[0].clear();
      stl.Display(buffer[0],true);
      disp->init_data(buffer);
      disp->reset_view();
      break;
  }
  delete chooser;
}

#endif
